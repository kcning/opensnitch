package orgvarlinkcertification

//go:generate go run ../../varlink-go-interface-generator/main.go org.varlink.certification.varlink
