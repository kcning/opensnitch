[![Build Status](https://github.com/varlink/go/workflows/Go/badge.svg)](https://github.com/varlink/go/actions?query=workflow%3AGo)
[![Go Report Card](https://goreportcard.com/badge/github.com/varlink/go)](https://goreportcard.com/report/github.com/varlink/go)
[![Go Doc](https://img.shields.io/badge/godoc-reference-blue.svg?style=flat-square)](http://godoc.org/github.com/varlink/go/varlink)
[![Coverage Status](https://coveralls.io/repos/github/varlink/go/badge.svg?branch=master)](https://coveralls.io/github/varlink/go?branch=master)
[![Release](https://img.shields.io/github/release/golang-standards/project-layout.svg?style=flat-square)](https://github.com/varlink/go/releases/latest)

# go/varlink

This is an implementation of the varlink protocol in golang.
An implementation of the varlink CLI tool in golang can be found on https://github.com/varlink/go-varlink-cmd
