package elf

import (
	"errors"
)

var (
	errNotSupported = errors.New("not supported")
)
