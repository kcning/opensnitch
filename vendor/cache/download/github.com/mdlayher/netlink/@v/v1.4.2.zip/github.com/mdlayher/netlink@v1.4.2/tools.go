//go:build tools
// +build tools

// This file is used to pin static analysis tool versions.
package main

import _ "honnef.co/go/tools/cmd/staticcheck"
