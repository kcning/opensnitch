<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fi_FI" sourcelanguage="en">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="34"/>
        <source>opensnitch-qt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="300"/>
        <source>User ID</source>
        <translation>Käyttäjä-ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="334"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Executed from&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Käynnistetty kohteesta&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="647"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="437"/>
        <source>Source IP</source>
        <translation>Lähde-IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="458"/>
        <source>Process ID</source>
        <translation>Prosessi-ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="601"/>
        <source>Destination IP</source>
        <translation>Kohde-IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="622"/>
        <source>Dst Port</source>
        <translation>Kohdeportti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="702"/>
        <source>from this executable</source>
        <translation>tästä ohjelmatiedostosta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="707"/>
        <source>from this command line</source>
        <translation>tästä komentorivistä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="712"/>
        <source>this destination port</source>
        <translation>tästä kohdeportista</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="717"/>
        <source>this user</source>
        <translation>tältä käyttäjältä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="722"/>
        <source>this destination ip</source>
        <translation>tästä kohde-IP:stä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="727"/>
        <source>from this PID</source>
        <translation>tästä PID:stä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="751"/>
        <source>once</source>
        <translation>kerran</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="756"/>
        <source>30s</source>
        <translation>30s</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="761"/>
        <source>5m</source>
        <translation>5m</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="766"/>
        <source>15m</source>
        <translation>15m</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="771"/>
        <source>30m</source>
        <translation>30m</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="776"/>
        <source>1h</source>
        <translation>1t</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="781"/>
        <source>until reboot</source>
        <translation>uudelleenkäynnistykseen asti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="786"/>
        <source>forever</source>
        <translation>ikuisesti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="809"/>
        <source>action</source>
        <translation>toiminto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="337"/>
        <source>Allow</source>
        <translation>Salli</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="865"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="14"/>
        <source>Firewall</source>
        <translation>Palomuuri</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Firewall&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Palomuuri&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="275"/>
        <source>Profile</source>
        <translation>Profiili</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="346"/>
        <source>Deny</source>
        <translation>Estä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="313"/>
        <source>Outbound</source>
        <translation>Lähtevä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="320"/>
        <source>Inbound</source>
        <translation>Tuleva</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="375"/>
        <source>Allow inbound connections to a port</source>
        <translation>Salli tulevat yhteydet porttiin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="378"/>
        <source>Allow service (IN)</source>
        <translation>Salli palvelu (IN)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="397"/>
        <source>Exclude outbound connections to a port from being intercepted</source>
        <translation>Poissulje porttiin lähtevät yhteydet sieppaukselta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="406"/>
        <source>Allow service (OUT)</source>
        <translation>Salli palvelu (OUT)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="426"/>
        <source>New rule</source>
        <translation>Uusi sääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="421"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="14"/>
        <source>Firewall rule</source>
        <translation>Palomuurisääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="26"/>
        <source>Node</source>
        <translation>Solmu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="38"/>
        <source>Enable</source>
        <translation>Ota käyttöön</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="50"/>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="90"/>
        <source>Simple</source>
        <translation>Yksinkertainen</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="154"/>
        <source>Add new condition</source>
        <translation>Lisää uusi ehto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="177"/>
        <source>Remove selected condition</source>
        <translation>Poista valittu ehto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="221"/>
        <source>Direction</source>
        <translation>Suunta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="232"/>
        <source>IN</source>
        <translation>IN</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="241"/>
        <source>OUT</source>
        <translation>OUT</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="250"/>
        <source>FORWARD</source>
        <translation>FORWARD</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="255"/>
        <source>PREROUTING</source>
        <translation>PREROUTING</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="260"/>
        <source>POSTROUTING</source>
        <translation>POSTROUTING</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="268"/>
        <source>Action</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="279"/>
        <source>ACCEPT</source>
        <translation>ACCEPT</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="288"/>
        <source>DROP</source>
        <translation>DROP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="297"/>
        <source>REJECT</source>
        <translation>REJECT</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="306"/>
        <source>RETURN</source>
        <translation>RETURN</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="315"/>
        <source>QUEUE</source>
        <translation>QUEUE</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="323"/>
        <source>DNAT</source>
        <translation>DNAT</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="328"/>
        <source>SNAT</source>
        <translation>SNAT</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="333"/>
        <source>REDIRECT</source>
        <translation>REDIRECT</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="349"/>
        <source>depending on the Action (i.e.: target), the syntaxis of the parameters will vary.
Some examples:

QUEUE -&gt; num 0 (or 1, 2, ...)
REDIRECT, TPROXY, DNAT, SNAT, MASQUERADE:
 to :22
 to 192.168.1.254:8080
 to 192.168.1.254
 to 1024-2048 (masquerade)</source>
        <translation>toiminnosta (eli kohteesta) riippuen parametrien syntaksi vaihtelee.
Joitakin esimerkkejä:

QUEUE -&gt; num 0 (or 1, 2, ...)
REDIRECT, TPROXY, DNAT, SNAT, MASQUERADE:
 to :22
 to 192.168.1.254:8080
 to 192.168.1.254
 to 1024-2048 (masquerade)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="432"/>
        <source>Clear</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="443"/>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="454"/>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="465"/>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="14"/>
        <source>Preferences</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="39"/>
        <source>Pop-ups</source>
        <translation>Ponnahdusikkunat</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="64"/>
        <source>Default options</source>
        <translation>Oletusasetukset</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="110"/>
        <source>If checked, this field will be selected when a pop-up is displayed</source>
        <translation>Jos tämä kenttä on valittuna, se valitaan, kun ponnahdusikkuna tulee näkyviin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="81"/>
        <source>User ID</source>
        <translation>Käyttäjä-ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="97"/>
        <source>Destination port</source>
        <translation>Kohdeportti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="113"/>
        <source>Destination IP</source>
        <translation>Kohde-IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1012"/>
        <source>deny</source>
        <translation>estä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1021"/>
        <source>allow</source>
        <translation>salli</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="147"/>
        <source>reject</source>
        <translation>hylkää</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pop-up default action.&lt;/p&gt;&lt;p&gt;When a new outgoing connection is about to be established, this action will be selected by default, so if the timeout fires, this is the option that will be applied.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;While a pop-up is asking the user to allow or deny a connection:&lt;/p&gt;&lt;p&gt;1. new outgoing connections are denied.&lt;/p&gt;&lt;p&gt;2. known connections are allowed or denied based on the rules defined by the user.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ponnahdusikkunan oletustoiminto.&lt;/p&gt;&lt;p&gt;Kun uutta lähtevää yhteyttä ollaan muodostamassa, tämä toiminto valitaan oletusarvoisesti.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Kun ponnahdusikkunassa kysytään käyttäjältä yhteyden sallimista tai kieltämistä:&lt;/p&gt;&lt;p&gt;1. Uudet lähtevät yhteydet kielletään.&lt;/p&gt;&lt;p&gt;2. Tunnetut yhteydet sallitaan tai kielletään käyttäjän määrittelemien sääntöjen perusteella.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="653"/>
        <source>Action</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="179"/>
        <source>center</source>
        <translation>keskellä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="184"/>
        <source>top right</source>
        <translation>ylhäällä, oikealla</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="189"/>
        <source>bottom right</source>
        <translation>alhaalla, oikealla</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="194"/>
        <source>top left</source>
        <translation>ylhäällä, vasemmalla</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="199"/>
        <source>bottom left</source>
        <translation>alhaalla, vasemmalla</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="970"/>
        <source>once</source>
        <translation>kerran</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="219"/>
        <source>30s</source>
        <translation>30s</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="224"/>
        <source>5m</source>
        <translation>5m</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="229"/>
        <source>15m</source>
        <translation>15m</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="234"/>
        <source>30m</source>
        <translation>30m</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="239"/>
        <source>1h</source>
        <translation>1t</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="244"/>
        <source>until reboot</source>
        <translation>uudelleenkäynnistykseen asti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="249"/>
        <source>forever</source>
        <translation>ikuisesti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="263"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;By default when a new pop-up appears, in its simplest form, you&apos;ll be able to filter connections or applications by one property of the connection (executable, port, IP, etc).&lt;/p&gt;&lt;p&gt;With these options, you can choose multiple fields to filter connections for.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Oletusarvoisesti kun uusi ponnahdusikkuna tulee näkyviin, yksinkertaisimmillaan voit suodattaa yhteyksiä tai sovelluksia yhden yhteyden ominaisuuden perusteella (ohjelmatiedosto, portti, IP-osoite jne.).&lt;/p&gt;&lt;p&gt;Vaihtoehtojen avulla voit valita useita kenttiä, joiden perusteella suodatat yhteyksiä.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="266"/>
        <source>Filter connections also by:</source>
        <translation>Suodata yhteydet myös seuraavilla tavoilla:</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="283"/>
        <source>by executable</source>
        <translation>ohjelmatiedostoston mukaan</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="288"/>
        <source>by command line</source>
        <translation>komentorivin mukaan</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="293"/>
        <source>by destination port</source>
        <translation>kohdeportin mukaan</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="298"/>
        <source>by destination ip</source>
        <translation>kohde-IP:n mukaan</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="303"/>
        <source>by user id</source>
        <translation>käyttäjä-ID:n mukaan</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="308"/>
        <source>by PID</source>
        <translation>PID:n mukaan</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="323"/>
        <source>Default target</source>
        <translation>Oletuskohde</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="330"/>
        <source>Default position on screen</source>
        <translation>Oletussijainti näytössä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="340"/>
        <source>Pop-up default duration</source>
        <translation>Ponnahdusikkunan oletuskesto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="343"/>
        <source>Duration</source>
        <translation>Kesto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="356"/>
        <source>The advanced view allows you to easily select multiple fields to filter connections</source>
        <translation>Edistyneessä näkymässä voit helposti valita useita kenttiä suodatettavia yhteyksiä varten</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="359"/>
        <source>Show advanced view by default</source>
        <translation>Näytä laajennettu näkymä oletusarvoisesti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="375"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the pop-ups will be displayed with the advanced view active.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Jos tämä on valittuna, ponnahdusikkunat näytetään, kun laajennettu näkymä on aktiivinen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="463"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This timeout is the countdown you see when a pop-up dialog is shown.&lt;/p&gt;&lt;p&gt;If the pop-up is not answered, the default options will be applied.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tämä aikakatkaisu on lähtölaskenta, joka näkyy, kun ponnahdusikkuna näytetään.&lt;/p&gt;&lt;p&gt;Jos ponnahdusikkunaan ei vastata, käytetään oletusasetuksia.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="466"/>
        <source>Default timeout</source>
        <translation>Oletusaikakatkaisu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="473"/>
        <source>Disable pop-ups, only display a notification</source>
        <translation>Poista ponnahdusikkunat käytöstä ja näytä vain ilmoitus</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="484"/>
        <source>UI</source>
        <translation>Käyttöliittymä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="496"/>
        <source>Desktop notifications</source>
        <translation>Työpöytäilmoitukset</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="514"/>
        <source>Use system notifications</source>
        <translation>Käytä järjestelmän ilmoituksia</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="530"/>
        <source>Use Qt notifications</source>
        <translation>Käytä Qt-ilmoituksia</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="559"/>
        <source>Test</source>
        <translation>Testaa</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="577"/>
        <source>Events tab columns</source>
        <translation>Tapahtumavälilehden sarakkeet</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="589"/>
        <source>Time</source>
        <translation>Aika</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="605"/>
        <source>Rule</source>
        <translation>Sääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="621"/>
        <source>Node</source>
        <translation>Solmu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="637"/>
        <source>Protocol</source>
        <translation>Protokolla</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="669"/>
        <source>Destination</source>
        <translation>Kohde</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="685"/>
        <source>Process</source>
        <translation>Prosessi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="695"/>
        <source>Command line</source>
        <translation>Komentorivi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="708"/>
        <source>Theme</source>
        <translation>Teema</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="716"/>
        <source>System</source>
        <translation>Järjestelmä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="724"/>
        <source>Language</source>
        <translation>Kieli</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="748"/>
        <source>Rules</source>
        <translation>Säännöt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="756"/>
        <source>When this option is selected, the rules of the selected duration won&apos;t be added to the list of temporary rules in the GUI.

Temporary rules will still be valid, and you can use them when prompted to allow/deny a new connection.</source>
        <translation>Kun tämä vaihtoehto on valittuna, valitun keston sääntöjä ei lisätä käyttöliittymän väliaikaisten sääntöjen luetteloon.

Väliaikaiset säännöt ovat edelleen voimassa, ja voit käyttää niitä, kun sinua pyydetään sallimaan/kieltämään uusi yhteys.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="761"/>
        <source>Don&apos;t save/Delete rules of duration</source>
        <translation>Älä tallenna/poista sääntöjä kestolta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="769"/>
        <source>any temporary rules</source>
        <translation>miltään väliaikaisilta säännöiltä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="779"/>
        <source>30s or less</source>
        <translation>30s tai vähemmältä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="784"/>
        <source>5m or less</source>
        <translation>5m tai vähemmältä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="789"/>
        <source>15m or less</source>
        <translation>15m tai vähemmältä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="794"/>
        <source>30m or less</source>
        <translation>30m tai vähemmältä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="799"/>
        <source>1h or less</source>
        <translation>1t tai vähemmältä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="823"/>
        <source>Nodes</source>
        <translation>Solmut</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="829"/>
        <source>Process monitor method</source>
        <translation>Prosessin monitorointimekanismi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="846"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Log file to write logs.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;/dev/stdout will print logs to the standard output.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Lokitiedosto lokien kirjoittamista varten.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;/dev/stdout tulostaa lokit vakiolähdölle.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="849"/>
        <source>Log file</source>
        <translation>Logitiedosto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="863"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The default duration will take place when there&apos;s no UI connected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Oletuskesto otetaan käyttöön, kun käyttöliittymää ei ole kytketty.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="866"/>
        <source>Default duration</source>
        <translation>Oletuskesto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="879"/>
        <source>Apply configuration to all nodes</source>
        <translation>Sovella asetuksia kaikkiin solmuihin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="902"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The default action will take place when there&apos;s no UI connected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Vakiotoiminto suoritetaan, kun käyttöliittymää ei ole yhdistetty.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="905"/>
        <source>Default action when the GUI is disconnected</source>
        <translation>Oletustoiminto, kun käyttöliittymän yhteys on katkaistu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="921"/>
        <source>HostName</source>
        <translation>Isäntänimi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="975"/>
        <source>until restart</source>
        <translation>uudelleenkäynnistykseen asti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="980"/>
        <source>always</source>
        <translation>aina</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="988"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Address of the node.&lt;/p&gt;&lt;p&gt;Default: unix:///tmp/osui.sock (unix:// is mandatory if it&apos;s a Unix socket)&lt;/p&gt;&lt;p&gt;It can also be an IP address with the port: 127.0.0.1:50051&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Solmun osoite.&lt;/p&gt;&lt;p&gt;Esimerkintä: unix:///tmp/osui.sock (unix:// on pakollinen, jos kyseessä on Unix-soketti)&lt;/p&gt;&lt;p&gt;Se voi olla myös IP-osoite portin kanssa: 127.0.0.1:50051&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="991"/>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="998"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, OpenSnitch will prompt you to allow or deny connections that don&apos;t have an associated PID, due to several reasons, mostly due to bad state connections.&lt;/p&gt;&lt;p&gt;The pop-up dialog will only contain information about the network connection.&lt;/p&gt;&lt;p&gt;There&apos;re some scenarios where these are valid connections though, like when establishing a VPN using WireGuard.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Jos valittuna, OpenSnitch pyytää sinua sallimaan tai kieltämään yhteydet, joihin ei ole liitetty PID:iä, useista syistä, useimmiten huonojen yksien takia.&lt;/p&gt;&lt;p&gt;Ponnahdusikkuna sisältää vain tietoja verkkoyhteydestä.&lt;/p&gt;&lt;p&gt;Jossain tilanteissa nämä yhteydet ovat kuitenkin kelvollisia yhteyksiä, kuten esimerkiksi luodessasi VPN:ää WireGuardin avulla.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1001"/>
        <source>Debug invalid connections</source>
        <translation>Vianmääritä virheellisiä yhteyksiä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1039"/>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1090"/>
        <source>unix:///tmp/osui.sock</source>
        <translation>unix:///tmp/osui.sock</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1102"/>
        <source>/var/log/opensnitchd.log</source>
        <translation>/var/log/opensnitchd.log</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1107"/>
        <source>/dev/stdout</source>
        <translation>/dev/stdout</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1131"/>
        <source>Default log level</source>
        <translation>Oletuslogitaso</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1146"/>
        <source>Database</source>
        <translation>Tietokanta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1181"/>
        <source>In memory</source>
        <translation>Muistissa</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1186"/>
        <source>File</source>
        <translation>Tiedostossa</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1200"/>
        <source>Database type</source>
        <translation>Tietokantatyyppi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1207"/>
        <source>Select</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1294"/>
        <source>minutes</source>
        <translation>minuuttia</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1326"/>
        <source>Minutes between events purges</source>
        <translation>Tapahtumien puhdistusväli minuuteissa</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1352"/>
        <source>days</source>
        <translation>päivää</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1365"/>
        <source>Maximum days of events to keep</source>
        <translation>Tapahtumien enimmäissäilytys päivissä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1482"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1493"/>
        <source>Apply</source>
        <translation>Toteuta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1504"/>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
</context>
<context>
    <name>ProcessDetailsDialog</name>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="14"/>
        <source>Process details</source>
        <translation>Prosessin tiedot</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="61"/>
        <source>loading...</source>
        <translation>ladataan...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="81"/>
        <source>CWD: loading...</source>
        <translation>CWD: ladataan...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="93"/>
        <source>mem stats: loading...</source>
        <translation>muistitilastot: ladataan...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="121"/>
        <source>Status</source>
        <translation>Tila</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="135"/>
        <source>Open files</source>
        <translation>Avoimet tiedostot</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="149"/>
        <source>I/O Statistics</source>
        <translation>I/O-tilastot</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="163"/>
        <source>Memory mapped files</source>
        <translation>Muistikartoitetut tiedostot</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="177"/>
        <source>Stack</source>
        <translation>Pino</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="191"/>
        <source>Environment variables</source>
        <translation>Ympäristömuuttujat</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="210"/>
        <source>Application pids</source>
        <translation>Sovelluksen PID:it</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="240"/>
        <source>Start or stop monitoring this process</source>
        <translation>Aloita tai pysäytä tämän prosessin monitorointi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="256"/>
        <source>Close</source>
        <translation>SUlje</translation>
    </message>
</context>
<context>
    <name>RulesDialog</name>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="20"/>
        <source>Rule</source>
        <translation>Sääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="56"/>
        <source>Action</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="89"/>
        <source>Duration</source>
        <translation>Kesto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="97"/>
        <source>once</source>
        <translation>kerran</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="127"/>
        <source>until reboot</source>
        <translation>uudelleenkäynnistykseen asti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="132"/>
        <source>always</source>
        <translation>aina</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="148"/>
        <source>Deny will just discard the connection</source>
        <translation>Esto vain sivuuttaa yhteyden</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="151"/>
        <source>Deny</source>
        <translation>Estä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="165"/>
        <source>Reject will drop the connection, and kill the socket that initiated it</source>
        <translation>Hylkäys pudottaa yhteyden ja tappaa sen aloittaneen liitännän</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="168"/>
        <source>Reject</source>
        <translation>Hylkää</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="185"/>
        <source>Allow will allow the connection</source>
        <translation>Salli sallii yhteyden</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="191"/>
        <source>Allow</source>
        <translation>Salli</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="207"/>
        <source>Enable</source>
        <translation>Ota käyttöön</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="214"/>
        <source>If checked, this rule will take precedence over the rest of the rules. No others rules will be checked after this one.

You must name the rule in such manner that it&apos;ll be checked first, because they&apos;re checked in alphabetical order. For example:

[x] Priority - 000-priority-rule
[  ] Priority - 001-less-priority-rule</source>
        <translation>Jos valintaruutu on valittuna, tämä sääntö on etusijalla muihin sääntöihin nähden. Muita sääntöjä ei tarkisteta tämän säännön jälkeen.

Sinun on nimettävä sääntö siten, että se tarkistetaan ensimmäisenä, koska säännöt tarkistetaan aakkosjärjestyksessä. Esimerkiksi:

[x] Prioriteetti - 000-prioriteettisääntö
[ ] Prioriteetti - 001-alhaisempi prioriteettisääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="222"/>
        <source>Priority rule</source>
        <translation>Prioriteettisääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="238"/>
        <source>The rules are checked in alphabetical order, so you can name them accordingly to prioritize them.

000-allow-localhost
001-deny-broadcast
...</source>
        <translation>Säännöt tarkistetaan aakkosjärjestyksessä, joten voit nimetä ne sen mukaan ja asettaa ne tärkeysjärjestykseen.

000-allow-localhost
001-deny-broadcast
...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="245"/>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="300"/>
        <source>Node</source>
        <translation>Solmu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="323"/>
        <source>Apply rule to all nodes</source>
        <translation>Sovella sääntöä kaikkiin solmuihin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="346"/>
        <source>Applications</source>
        <translation>Sovellukset</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="355"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The value of this field is always the absolute path to the executable: /path/to/binary&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Examples:&lt;/p&gt;&lt;p&gt;- Simple: /path/to/binary&lt;/p&gt;&lt;p&gt;- Multiple paths: ^/usr/lib(64|)/firefox/firefox$&lt;/p&gt;&lt;p&gt;- Multiple binaries: ^(/usr/sbin/ntpd|/lib/systemd/systemd-timesyncd|/usr/bin/xbrlapi|/usr/bin/dirmngr)$ &lt;/p&gt;&lt;p&gt;- Deny/Allow executions from /tmp:&lt;/p&gt;&lt;p&gt;^/(var/|)tmp/.*$&lt;br/&gt;&lt;/p&gt;&lt;p&gt;For more examples visit the &lt;a href=&quot;https://github.com/evilsocket/opensnitch/wiki/Rules-examples&quot;&gt;wiki page&lt;/a&gt; or ask on the &lt;a href=&quot;https://github.com/evilsocket/opensnitch/discussions&quot;&gt;Discussion forums&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tämän kentän arvo on aina suoritettavan tiedoston absoluuttinen polku: /path/to/binary&lt;br/&gt;&lt;/p&gt;&lt;p&gt; Esimerkkejä:&lt;/p&gt;&lt;p&gt;- Simple: /&lt;/p&gt;&lt;p&gt;- Useita polkuja: ^/usr/lib(64|)/firefox/firefox$&lt;/p&gt;&lt;p&gt;- Useita binäärejä: ^(/usr/sbin/ntpd|/lib/systemd/systemd-timesyncd|/usr/bin/xbrlapi|/usr/bin/dirmngr)$ &lt;/p&gt;&lt;p&gt;- Kielletään/sallitaan suoritukset /tmp:stä:&lt;/p&gt;&lt;p&gt;^/(var/|)tmp/.*$&lt;br/&gt;&lt;/p&gt;&lt;p&gt; Lisää esimerkkejä löydät &lt;a href=&quot;https://github.com/evilsocket/opensnitch/wiki/Rules-examples&quot;&gt;wiki-sivulta&lt;/a&gt; tai kysy &lt;a href=&quot;https://github.com/evilsocket/opensnitch/discussions&quot;&gt;keskustelufoorumeilla&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="365"/>
        <source>Is regular expression</source>
        <translation>Onko säännöllinen lauseke</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="372"/>
        <source>From this user ID</source>
        <translation>Tältä käyttäjä-ID:ltä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="379"/>
        <source>From this command line</source>
        <translation>Tästä komentorivistä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="389"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This field will contain and match the command line that was executed by the user.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;If the user typed the command, only the command will appear:&lt;/p&gt;&lt;p&gt;telnet 1.2.3.4&lt;br/&gt;&lt;/p&gt;&lt;p&gt;If the user typed the absolute or relative path to the command, that is what will appear:&lt;/p&gt;&lt;p&gt;/usr/bin/telnet 1.2.3.4&lt;/p&gt;&lt;p&gt;../../../usr/bin/telnet 1.2.3.4&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tämä kenttä sisältää käyttäjän suorittaman komentorivin ja vastaa sitä.&lt;br/&gt;&lt;/p&gt;&lt;p&gt; Jos käyttäjä kirjoitti komennon, vain komento näkyy:&lt;/p&gt;&lt;p&gt;telnet 1.2.3.4&lt;br/&gt;&lt;/p&gt;&lt;p&gt; Jos käyttäjä kirjoitti komennon absoluuttisen tai suhteellisen polun, se näkyy:&lt;/p&gt;&lt;p&gt;/usr/bin/telnet 1.2.3.4&lt;/p&gt;&lt;p&gt;../../../../usr/bin/telnet 1.2.3.4.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="399"/>
        <source>From this PID</source>
        <translation>Tästä PID:istä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="466"/>
        <source>From this executable</source>
        <translation>Tästä ohjelmatiedostosta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="473"/>
        <source>is regular expression</source>
        <translation>on säännöllinen lauseke</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="485"/>
        <source>Network</source>
        <translation>Verkko</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="520"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Only TCP, UDP or UDPLITE are allowed&lt;/p&gt;&lt;p&gt;You can use regexp, i.e.: ^(TCP|UDP)$&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Vain TCP, UDP tai UDPLITE ovat sallittuja&lt;/p&gt;&lt;p&gt;Voit käyttää regexp:iä, esim: ^(TCP|UDP)$&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="526"/>
        <source>TCP</source>
        <translation>TCP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="560"/>
        <source>ICMP</source>
        <translation>ICMP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="565"/>
        <source>ICMP6</source>
        <translation>ICMP6</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="570"/>
        <source>SCTP</source>
        <translation>SCTP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="575"/>
        <source>SCTP6</source>
        <translation>SCTP6</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="586"/>
        <source>Commas or spaces are not allowed to specify multiple domains. 

Use regular expressions instead: 
.*(opensnitch|duckduckgo).com
.*\.google.com

or a single domain:
www.gnu.org - it&apos;ll only match www.gnu.org, nor ftp.gnu.org, nor www2.gnu.org, ...
gnu.org         - it&apos;ll only match gnu.org, nor www.gnu.org, nor ftp.gnu.org, ...</source>
        <translation>Pilkut tai välilyönnit eivät ole sallittuja useiden toimialueiden määrittämisessä. 

Käytä sen sijaan säännöllisiä lausekkeita: 
.*(opensnitch|duckduckgo).com&quot;.
.*\.google.com

tai yksittäinen verkkotunnus:
www.gnu.org - se vastaa vain www.gnu.org, eikä ftp.gnu.org, eikä www2.gnu.org, ...
gnu.org - vain gnu.org, www.gnu.org, ftp.gnu.org, ...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="597"/>
        <source>www.domain.org, .*\.domain.org</source>
        <translation>www.domain.org, .*\.domain.org</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="604"/>
        <source>To this IP / Network</source>
        <translation>Tähän IP-osoitteeseen / verkkoon</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="627"/>
        <source>Protocol</source>
        <translation>Protokolla</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="754"/>
        <source>You can specify a single IP:
- 192.168.1.1

or a regular expression:
- 192\.168\.1\.[0-9]+

multiple IPs:
- ^(192\.168\.1\.1|172\.16\.0\.1)$

You can also specify a subnet:
- 192.168.1.0/24

Note: Commas or spaces are not allowed to separate IPs or networks.</source>
        <translation>Voit määrittää yhden IP-osoitteen:
- 192.168.1.1

tai säännöllisen lausekkeen:
- 192\.168\.1\.[0-9]+

useita IP-osoitteita:
- ^(192\.168\.1\.1|172\.16\.0\.1)$

Voit myös määrittää aliverkon:
- 192.168.1.0/24

Huomautus: Pilkut tai välilyönnit eivät saa erottaa IP-osoitteita tai verkkoja toisistaan.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="659"/>
        <source>LAN</source>
        <translation>LAN</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="664"/>
        <source>MULTICAST</source>
        <translation>MULTICAST</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="669"/>
        <source>127.0.0.0/8</source>
        <translation>127.0.0.0/8</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="674"/>
        <source>192.168.0.0/24</source>
        <translation>192.168.0.0/24</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="679"/>
        <source>192.168.1.0/24</source>
        <translation>192.168.1.0/24</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="684"/>
        <source>192.168.2.0/24</source>
        <translation>192.168.2.0/24</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="689"/>
        <source>192.168.0.0/16</source>
        <translation>192.168.0.0/16</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="694"/>
        <source>169.254.0.0/16</source>
        <translation>169.254.0.0/16</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="699"/>
        <source>172.16.0.0/12</source>
        <translation>172.16.0.0/12</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="704"/>
        <source>10.0.0.0/8</source>
        <translation>10.0.0.0/8</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="709"/>
        <source>::1/128</source>
        <translation>::1/128</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="714"/>
        <source>fc00::/7</source>
        <translation>fc00::/7</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="719"/>
        <source>ff00::/8</source>
        <translation>ff00::/8</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="724"/>
        <source>fe80::/10</source>
        <translation>fe80::/10</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="729"/>
        <source>fd00::/8</source>
        <translation>fd00::/8</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="737"/>
        <source>From this IP / Network</source>
        <translation>Tästä IP-osoitteesta / verkosta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="744"/>
        <source>To this host</source>
        <translation>Tälle isännälle</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="857"/>
        <source>Network interface</source>
        <translation>Verkkoliitäntä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="866"/>
        <source>From this port</source>
        <translation>Tästä portista</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="912"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;You can specify multiple ports using regular expressions:&lt;/p&gt;&lt;p&gt;- 53, 80 or 443:&lt;/p&gt;&lt;p&gt;^(53|80|443)$&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;- 53, 443 or 5551, 5552, 5553, etc:&lt;/p&gt;&lt;p&gt;^(53|443|555[0-9])$&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Voit määrittää useita portteja käyttämällä säännöllisiä lausekkeita:&lt;/p&gt;&lt;p&gt;- 53, 80 tai 443:&lt;/p&gt;&lt;p&gt;^(53|80|443)$&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt; &lt;p&gt; - 53, 443 tai 5551, 5552, 5553, jne:&lt;/p&gt;&lt;p&gt;^(53|443|555[0-9])$.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="896"/>
        <source>To this port</source>
        <translation>Tähän porttiin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="926"/>
        <source>List of domains/IPs</source>
        <translation>Luettelo verkkotunnuksista/IP-osoitteista</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="932"/>
        <source>To this list of network ranges</source>
        <translation>Tähän verkkoalueiden luetteloon</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="939"/>
        <source>To this list of IPs</source>
        <translation>Tähän IP-osoitteiden luetteloon</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="965"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory with files containing list of IPs to block or allow:&lt;/p&gt;&lt;p&gt;1.2.3.4.5&lt;/p&gt;&lt;p&gt;1.2.3.4.6&lt;/p&gt;&lt;p&gt;.&lt;/p&gt;&lt;p&gt;etc.&lt;/p&gt;&lt;p&gt;One IP per line. Empty lines or started with # are ignored.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Valitse hakemisto, jossa on estettävien tai sallittujen IP-osoitteiden luettelon sisältäviä tiedostoja:&lt;/p&gt;&lt;p&gt;1.2.3.4.5&lt;/p&gt;&lt;p&gt;1.2.3.4.6&lt;/p&gt;&lt;p&gt;.&lt;/p&gt;&lt;p&gt;jne.&lt;/p&gt;&lt;p&gt;Yksi IP-osoite per rivi. Tyhjät tai #-alkuiset rivit jätetään huomiotta.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="974"/>
        <source>To this list of domains</source>
        <translation>Tähän verkkotunnusten luetteloon</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1000"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory with files containing list of network ranges to block or allow:&lt;/p&gt;&lt;p&gt;1.2.3.0/24&lt;/p&gt;&lt;p&gt;80.34.56.0/20&lt;/p&gt;&lt;p&gt;.&lt;/p&gt;&lt;p&gt;etc.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;One Network Range per line. Empty lines or started with # are ignored.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Valitse hakemisto, jossa on estettävien tai sallittujen verkkoalueiden luettelon sisältäviä tiedostoja:&lt;/p&gt;&lt;p&gt;1.2.3.0/24&lt;/p&gt;&lt;p&gt;80.34.56.0/20&lt;/p&gt;&lt;p&gt;.&lt;/p&gt;&lt;p&gt;jne.&lt;br/&gt;&lt;/p&gt;&lt;p&gt; Yksi verkkoalue per rivi. Tyhjät tai #-alkuiset rivit jätetään huomiotta.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1028"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory with lists of domains to block or allow.&lt;/p&gt;&lt;p&gt;Put inside that directory files with any extension containing lists of domains.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;The format of each entry of a list is as follow (hosts format):&lt;/p&gt;&lt;p&gt;127.0.0.1 www.domain.com&lt;/p&gt;&lt;p&gt;or &lt;/p&gt;&lt;p&gt;0.0.0.0 www.domain.com&lt;/p&gt;&lt;p&gt;Empty lines or started with # are ignored.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Valitse hakemisto, jossa on luetteloita estettävistä tai sallittavista verkkotunnuksista.&lt;/p&gt;&lt;p&gt;Laita kyseiseen hakemistoon minkä tahansa tiedostopäätteen omaavia tiedostoja, jotka sisältävät luetteloita verkkotunnuksista.&lt;/p&gt;&lt;p&gt;&lt;br/&gt; Luettelon jokaisen merkinnän muoto on seuraava (hosts-muodossa):&lt;/p&gt;&lt;p&gt;127.0.0.1 www.domain.com&lt;/p&gt;&lt;p&gt;tai &lt;/p&gt;&lt;p&gt;0.0.0.0.0 www.domain.com&lt;/p&gt;&lt;p&gt;Tyhjiä rivejä tai rivejä, jotka alkavat merkinnällä #, ei huomioida.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1043"/>
        <source>To this list of domains 
(regular expressions)</source>
        <translation>Tähän verkkotunnusten luetteloon 
(säännölliset lausekkeet)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1070"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory with files containing regular expressions of domains to block or allow:&lt;/p&gt;&lt;p&gt;.*\.example\.com&lt;/p&gt;&lt;p&gt;You can also use a domain as is: &amp;quot;example.com&amp;quot; , and it&apos;ll match whatever.example.com, whatever.example.com.localdomain, etc.&lt;/p&gt;&lt;p&gt;One domain per line. Empty lines or started with # are ignored.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Valitse hakemisto, jossa on tiedostoja, jotka sisältävät säännöllisiä lausekkeita estettävistä tai sallittavista verkkotunnuksista:&lt;/p&gt;&lt;p&gt;.*\.example\.com&lt;/p&gt;&lt;p&gt;Voit myös käyttää verkkotunnusta sellaisenaan: &amp;quot;example.com&amp;quot;, jolloin se vastaa whatever.example.com, whatever.example.com.localdomain jne.&lt;/p&gt;&lt;p&gt;Yksi verkkotunnus riviä kohti. Tyhjät tai #-alkuiset rivit jätetään huomiotta.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1080"/>
        <source>More</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1086"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;By default, the field of the rules are case-insensitive, i.e., if a process tries to access gOOgle.CoM and you have a rule to Deny .*google.com, the connection will be blocked.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;If you check this box, you have to specify the exact string (domain, executable, command line) that you want to filter.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Oletusarvoisesti sääntöjen kentässä ei oteta huomioon isoja ja pieniä kirjaimia, eli jos prosessi yrittää käyttää gOOgle.CoM:ää ja sinulla on sääntö Deny .*google.com, yhteys estetään.&lt;br/&gt;&lt;/p&gt;&lt;p&gt; Jos ruksaat tämän ruudun, sinun on määritettävä tarkka merkkijono (verkkotunnus, suoritettava ohjelma, komentorivi), jonka haluat suodattaa.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1089"/>
        <source>Case-sensitive</source>
        <translation>Kirjainkoolla on merkitystä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1096"/>
        <source>Don&apos;t log connections that match this rule</source>
        <translation>Älä logita yhteyksiä, jotka vastaavat tätä sääntöä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1099"/>
        <source>Don&apos;t log connections</source>
        <translation>Älä logita yhteyksiä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1145"/>
        <source>Description...</source>
        <translation>Kuvaus...</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="34"/>
        <source>OpenSnitch Network Statistics</source>
        <translation>OpenSnitch -verkkotilastot</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="94"/>
        <source>Filter</source>
        <translation>Suodatin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1793"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="107"/>
        <source>Allow</source>
        <translation>Salli</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="116"/>
        <source>Deny</source>
        <translation>Estä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="125"/>
        <source>Reject</source>
        <translation>Hylkää</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="143"/>
        <source>Ex.: firefox</source>
        <translation>Esim.: firefox</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="180"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="205"/>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="210"/>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="215"/>
        <source>200</source>
        <translation>200</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="220"/>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="233"/>
        <source>Delete all intercepted events</source>
        <translation>Poista kaikki kaapatut tapahtumat</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="333"/>
        <source>Create a new rule</source>
        <translation>Luo uusi sääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="376"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;hostname - 192.168.1.1&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;hostname - 192.168.1.1.1&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="413"/>
        <source>Status</source>
        <translation>Tila</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="451"/>
        <source>Start or Stop interception</source>
        <translation>Aloita tai lopeta kaappaus</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="496"/>
        <source>Events</source>
        <translation>Tapahtumat</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="826"/>
        <source>Nodes</source>
        <translation>Solmut</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="637"/>
        <source>Delete this node</source>
        <translation>Poista tämä solmu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="653"/>
        <source>Show the preferences of this node</source>
        <translation>Näytä tämän solmun asetukset</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="669"/>
        <source>Start or stop interception of this node</source>
        <translation>Tämän solmun kuuntelun aloittaminen tai lopettaminen</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1700"/>
        <source>Rules</source>
        <translation>Säännöt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="777"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="782"/>
        <source>Application rules</source>
        <translation>Sovellussäännöt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="936"/>
        <source>Permanent</source>
        <translation>Pysyvä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="945"/>
        <source>Temporary</source>
        <translation>Väliaikainen</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="954"/>
        <source>System rules</source>
        <translation>Järjestelmän säännöt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="927"/>
        <source>All applications</source>
        <translation>Kaikki sovellukset</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="995"/>
        <source>enable</source>
        <translation>ota käyttöön</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1022"/>
        <source>Edit rule</source>
        <translation>Muokkaa sääntöä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1039"/>
        <source>Delete rule</source>
        <translation>Poista sääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1063"/>
        <source>Hosts</source>
        <translation>Isännät</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1153"/>
        <source>Applications</source>
        <translation>Sovellukset</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1266"/>
        <source>Addresses</source>
        <translation>Osoitteet</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1356"/>
        <source>Ports</source>
        <translation>Portit</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1440"/>
        <source>Users</source>
        <translation>Käyttäjät</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1544"/>
        <source>Connections</source>
        <translation>Yhteydet</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1596"/>
        <source>Dropped</source>
        <translation>Pudotetut</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1648"/>
        <source>Uptime</source>
        <translation>Käynnissäoloaika</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1767"/>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
</context>
<context>
    <name>contextual_menu</name>
    <message>
        <location filename="../../../opensnitch/service.py" line="47"/>
        <source>Statistics</source>
        <translation>Tilastot</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="48"/>
        <source>Enable</source>
        <translation>Ota käyttöön</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="49"/>
        <source>Disable</source>
        <translation>Poista käytöstä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="50"/>
        <source>Help</source>
        <translation>Apua</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="51"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
</context>
<context>
    <name>firewall</name>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="91"/>
        <source>Configuration applied.</source>
        <translation>Asetukset toteutettu.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="404"/>
        <source>Error: {0}</source>
        <translation>Virhe: {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="193"/>
        <source>Applying changes...</source>
        <translation>Toteutetaan muutoksia...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="230"/>
        <source>Error getting INPUT chain policy</source>
        <translation>Virhe INPUT-ketjun käytännön saamisessa</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="237"/>
        <source>Error getting OUTPUT chain policy</source>
        <translation>Virhe OUTPUT-ketjun käytännön saamisessa</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="290"/>
        <source>In order to configure firewall rules from the GUI, we need to use &apos;nftables&apos; instead of &apos;iptables&apos;</source>
        <translation>Jotta voimme määrittää palomuurisääntöjä käyttöliittymästä, meidän on käytettävä &apos;nftables&apos;-ohjelmaa &apos;iptables&apos;-ohjelman sijasta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="304"/>
        <source>Enabling firewall...</source>
        <translation>Otetaan käyttöön palomuuria...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="306"/>
        <source>Disabling firewall...</source>
        <translation>Otetaan palomuuria pois käytöstä...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="71"/>
        <source>Dest Port</source>
        <translation>Kohdeportti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="72"/>
        <source>Source Port</source>
        <translation>Lähdeportti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="73"/>
        <source>Dest IP</source>
        <translation>Kohde-IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="74"/>
        <source>Source IP</source>
        <translation>Lähde-IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="75"/>
        <source>Input interface</source>
        <translation>Tuloliitäntä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="76"/>
        <source>Output interface</source>
        <translation>Lähtöliitäntä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="77"/>
        <source>Set conntrack mark</source>
        <translation>Aseta conntrack-merkki</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="78"/>
        <source>Match conntrack mark</source>
        <translation>Kohdista conntrack-merkki</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="79"/>
        <source>Match conntrack state(s)</source>
        <translation>Kohdista conntrack-tila(t)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="80"/>
        <source>Set mark on packet</source>
        <translation>Aseta merkki pakettiin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="81"/>
        <source>Match packet information</source>
        <translation>Kohdista pakettitiedot</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="87"/>
        <source>Bandwidth quotas</source>
        <translation>Kaistanleveyskiintiöt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="89"/>
        <source>Rate limit connections</source>
        <translation>Nopeusrajoita yhteyksiä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="108"/>
        <source>
Supported formats:

 - Simple: 23
 - Ranges: 80-1024
 - Multiple ports: 80,443,8080
</source>
        <translation>
Tuetut formaatit:

 - 23
 - Alueet: 80-1024
 - Useita portteja: 80,443,8080
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="134"/>
        <source>
Supported formats:

 - Simple: 1.2.3.4
 - IP ranges: 1.2.3.100-1.2.3.200
 - Network ranges: 1.2.3.4/24
</source>
        <translation>
Tuetut formaatit:

 - 1.2.3.4
 - IP-alueet: 1.2.3.100-1.2.3.200
 - Verkkoalueet: 1.2.3.4/24
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="147"/>
        <source>Match input interface. Regular expressions not allowed.</source>
        <translation>Kohdista tuloliitäntä. Säännölliset lausekkeet eivät ole sallittuja.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="154"/>
        <source>Match output interface. Regular expressions not allowed.</source>
        <translation>Sovita lähtöliitäntä. Säännölliset lausekkeet eivät ole sallittuja.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="161"/>
        <source>Set a conntrack mark on the connection, in decimal format.</source>
        <translation>Asettaa yhteyden conntrack-merkki desimaalimuodossa.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="171"/>
        <source>Match a conntrack mark of the connection, in decimal format.</source>
        <translation>Kohdista yhteyden conntrack-merkki, desimaalimuodossa.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="178"/>
        <source>Match conntrack states.

Supported formats:
 - Simple: new
 - Multiple states separated by commas: related,new
</source>
        <translation>Kohdista conntrack-tilat.

Tuetut formaatit:
 - Yksinkertainen: new
 - Useita tiloja pilkulla erotettuna: related,new
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="193"/>
        <source>
Match packet&apos;s metainformation.

Value must be in decimal format, except for the &quot;l4proto&quot; option.
For l4proto it can be a lower case string, for example:
 tcp
 udp
 icmp,
 etc

If the value is decimal for protocol or lproto, it&apos;ll use it as the code of
that protocol.
</source>
        <translation>
Match-paketin metatiedot.

Arvon on oltava desimaalimuodossa, paitsi &quot;l4proto&quot;-vaihtoehdon tapauksessa.
l4proto voi olla esimerkiksi pienellä alkukirjaimella kirjoitettu merkkijono:
 tcp
 udp
 icmp,
 jne

Jos protokollan tai lproton arvo on desimaalinen, se käyttää sitä koodina, joka on
protokollan koodina.
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="213"/>
        <source>Set a mark on the packet matching the specified conditions. The value is in decimal format.</source>
        <translation>Asettaa paketille merkki, joka vastaa määritettyjä ehtoja. Arvo on desimaalimuodossa.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="221"/>
        <source>
Match ICMP codes.

Supported formats:
 - Simple: echo-request
 - Multiple separated by commas: echo-request,echo-reply
</source>
        <translation>
Kohdista ICMP-koodit.

Tuetut muodot:
 - Yksinkertainen: echo-request
 - Useita pilkulla erotettuna: echo-request,echo-reply
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="234"/>
        <source>
Match ICMPv6 codes.

Supported formats:
 - Simple: echo-request
 - Multiple separated by commas: echo-request,echo-reply
</source>
        <translation>
Kohista ICMPv6-koodit.

Tuetut muodot:
 - Yksinkertainen: echo-request
 - Useita pilkulla erotettuna: echo-request,echo-reply
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="247"/>
        <source>Print a message when this rule matches a packet.</source>
        <translation>Tulostaa viestin, kun tämä sääntö vastaa pakettia.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="254"/>
        <source>
Apply quotas on connections.

For example when:
 - &quot;quota over 10/mbytes&quot; -&gt; apply the Action defined (DROP)
 - &quot;quota until 10/mbytes&quot; -&gt; apply the Action defined (ACCEPT)

The value must be in the format: VALUE/UNITS, for example:
 - 10mbytes, 1/gbytes, etc
</source>
        <translation>
Sovelletaan kiintiöitä yhteyksiin.

Esimerkiksi kun:
 - Sovelletaan määriteltyä toimintoa (DROP), esimerkiksi: &quot;kiintiö yli 10 megatavua&quot;.
 - &quot;kiintiö enintään 10 megatavua&quot; -&gt; sovelletaan määriteltyä toimintoa (ACCEPT).

Arvon on oltava muotoa: VALUE/UNITS, esimerkiksi:
 - 10mbytes, 1/gbytes, jne
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="286"/>
        <source>
Apply limits on connections.

For example when:
 - &quot;limit over 10/mbytes/minute&quot; -&gt; apply the Action defined (DROP, ACCEPT, etc)
    (When there&apos;re more than 10MB per minute, apply an Action)

 - &quot;limit until 10/mbytes/hour&quot; -&gt; apply the Action defined (ACCEPT)

The value must be in the format: VALUE/UNITS/TIME, for example:
 - 10/mbytes/minute, 1/gbytes/hour, etc
</source>
        <translation>
Rajoita yhteyksiä.

Esimerkiksi kun:
 - Sovelletaan määriteltyä toimintoa (DROP, ACCEPT jne.).
    (Kun yhteyksiä on yli 10 Mt minuutissa, sovelletaan toimintoa).

 - &quot;rajoitus enintään 10 megatavua/tunti&quot; -&gt; sovelletaan määriteltyä toimintoa (ACCEPT).

Arvon on oltava muotoa: VALUE/UNITS/TIME, esimerkiksi:
 - 10/mbytes/minute, 1/gbytes/hour, jne
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="373"/>
        <source>Your protobuf version is incompatible, you need to install protobuf 3.8.0 or superior
(pip3 install --ignore-installed protobuf==3.8.0)</source>
        <translation>Protobuf-versiosi ei ole yhteensopiva, sinun on asennettava protobuf 3.8.0 tai uudempi versio.
(pip3 install --ignore-installed protobuf==3.8.0)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="397"/>
        <source>Rule deleted</source>
        <translation>Sääntö poistettu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="401"/>
        <source>Rule added</source>
        <translation>Sääntö lisätty</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="420"/>
        <source>You can use &apos;,&apos; or &apos;-&apos; to specify multiple ports/IPs or ranges/values:&lt;br&gt;&lt;br&gt;ports: 22 or 22,443 or 50000-60000&lt;br&gt;IPs: 192.168.1.1 or 192.168.1.30-192.168.1.130&lt;br&gt;Values: echo-reply,echo-request&lt;br&gt;Values: new,established,related</source>
        <translation>Voit käyttää &apos;,&apos; tai &apos;-&apos; -merkkejä määrittääksesi useita portteja/IP-osoitteita tai alueita/arvoja:&lt;br&gt;&lt;br&gt;ports: 22 tai 22,443 tai 50000-60000&lt;br&gt;IP:t: 192.168.1.1 tai 192.168.1.30-192.168.1.130&lt;br&gt;arvot: echo-reply,echo-request&lt;br&gt;arvot: new,established,related</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="440"/>
        <source>Deleting rule, wait</source>
        <translation>Poistetaan sääntöä, odota</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="443"/>
        <source>Error updating rule</source>
        <translation>Virhe säännön päivittämisessä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="483"/>
        <source>Adding rule, wait</source>
        <translation>Lisäätään sääntöä, odota</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="492"/>
        <source>&lt;select a statement&gt;</source>
        <translation>&lt;valitse lausuma&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="607"/>
        <source>num</source>
        <translation>num</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="621"/>
        <source>to</source>
        <translation>kohteeseen</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="787"/>
        <source>Equal</source>
        <translation>Yhtä suuri</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="788"/>
        <source>Not equal</source>
        <translation>Ei yhtäläinen</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="789"/>
        <source>Greater or equal than</source>
        <translation>Suurempi tai yhtä suuri kuin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="790"/>
        <source>Greater than</source>
        <translation>Suurempi kuin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="791"/>
        <source>Less or equal than</source>
        <translation>Pienempi tai yhtä suuri kuin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="792"/>
        <source>Less than</source>
        <translation>Vähemmän kuin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1350"/>
        <source>Firewall rule</source>
        <translation>Palomuurisääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="885"/>
        <source>Simple</source>
        <translation>Yksinkertainen</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="890"/>
        <source>Advanced</source>
        <translation>Edistynyt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1046"/>
        <source>This rule is not supported yet.</source>
        <translation>Tätä sääntöä ei vielä tueta.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1111"/>
        <source>Exclude service</source>
        <translation>Sulje palvelu pois</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1123"/>
        <source>Allow inbound connections to the selected port.</source>
        <translation>Salli saapuvat yhteydet valittuun porttiin.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1125"/>
        <source>Allow outbound connections to the selected port.</source>
        <translation>Salli lähtevät yhteydet valittuun porttiin.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1201"/>
        <source>select a statement.</source>
        <translation>valitse lausuma.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1217"/>
        <source>value cannot be 0 or empty.</source>
        <translation>arvo ei voi olla 0 tai tyhjä.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1229"/>
        <source>the value format is 1024/kbytes (or bytes, mbytes, gbytes)</source>
        <translation>arvomuoto on 1024/kbytes (tai bytes, mbytes, gbytes)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1240"/>
        <source>the value format is 1024/kbytes/second (or bytes, mbytes, gbytes)</source>
        <translation>arvomuoto on 1024 kbytes/sekunti (tai bytes, mbytes, gbytes)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1243"/>
        <source>rate-limit not valid, use: bytes, kbytes, mbytes or gbytes.</source>
        <translation>rajoitus ei kelpaa, käytä: bytes, kbytes, mbytes tai gbytes.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1245"/>
        <source>time-limit not valid, use: second, minute, hour or day</source>
        <translation>aikaraja ei ole voimassa, käytä: second, minute, hour tai day</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1293"/>
        <source>port not valid.</source>
        <translation>portti ei kelpaa.</translation>
    </message>
</context>
<context>
    <name>messages</name>
    <message>
        <location filename="../../../opensnitch/service.py" line="281"/>
        <source>Info</source>
        <translation>Tiedot</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="285"/>
        <source>Error</source>
        <translation>Virheet</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="289"/>
        <source>Warning</source>
        <translation>Varoitukset</translation>
    </message>
</context>
<context>
    <name>notifications</name>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="654"/>
        <source>System notifications are not available, you need to install python3-notify2.</source>
        <translation>Järjestelmäilmoitukset eivät ole käytettävissä, sinun on asennettava python3-notify2.</translation>
    </message>
</context>
<context>
    <name>popups</name>
    <message>
        <location filename="../../../opensnitch/notifications.py" line="42"/>
        <source>Open</source>
        <translation>Avaa</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="115"/>
        <source>Allow</source>
        <translation>Salli</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="114"/>
        <source>Deny</source>
        <translation>Estä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/notifications.py" line="122"/>
        <source>New outgoing connection</source>
        <translation>Uusi lähtevä yhteys</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="490"/>
        <source>is connecting to &lt;b&gt;%s&lt;/b&gt; on %s port %d</source>
        <translation>on yhdistämässä &lt;b&gt;%s&lt;/b&gt; kohteen %s portissa %d</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="50"/>
        <source>until reboot</source>
        <translation>uudelleenkäynnistykseen asti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="52"/>
        <source>forever</source>
        <translation>ikuisesti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="116"/>
        <source>Reject</source>
        <translation>Hylkää</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="331"/>
        <source>Outgoing connection</source>
        <translation>Lähtevä yhteys</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="336"/>
        <source>Process launched from:</source>
        <translation>Prosessi käynnistetty kohteesta:</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="373"/>
        <source>from this executable</source>
        <translation>tästä ohjelmatiedostosta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="377"/>
        <source>from this command line</source>
        <translation>tästä komentorivistä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="379"/>
        <source>to port {0}</source>
        <translation>porttiin {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="442"/>
        <source>to {0}</source>
        <translation>kohteeseen {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="382"/>
        <source>from user {0}</source>
        <translation>käyttäjältä {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="386"/>
        <source>from this PID</source>
        <translation>tästä PID:istä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="399"/>
        <source>to {0}.*</source>
        <translation>kohteeseen {0}.*</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="452"/>
        <source>to *.{0}</source>
        <translation>kohteeseen *.{0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="486"/>
        <source>&lt;b&gt;Remote&lt;/b&gt; process %s running on &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;Etä&lt;/b&gt;prosessi %s on käynnissä kohteessa &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="497"/>
        <source>is connecting to &lt;b&gt;%s&lt;/b&gt;, %s</source>
        <translation>yhdistää kohteeseen &lt;b&gt;%s&lt;/b&gt;, %s</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="502"/>
        <source>is attempting to resolve &lt;b&gt;%s&lt;/b&gt; via %s, %s port %d</source>
        <translation>yrittää selvittää &lt;b&gt;%s&lt;/b&gt;%s, %s portti %d kautta</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="410"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="38"/>
        <source>Restart the GUI in order effects to take effect</source>
        <translation>Uudelleenkäynnistä käyttöliittymä uudelleen, jotta muutokset tulevat voimaan</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="388"/>
        <source>There&apos;re no nodes connected</source>
        <translation>Solmuja ei ole yhdistetty</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="164"/>
        <source>System default</source>
        <translation>Järjestelmän oletus</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="466"/>
        <source>System</source>
        <translation>Järjestelmä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="187"/>
        <source>Themes not available. Install qt-material: pip3 install qt-material</source>
        <translation>Teemat eivät ole käytettävissä. Asenna qt-material: pip3 install qt-material</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="292"/>
        <source>Server address can not be empty</source>
        <translation>Palvelimen osoite ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="321"/>
        <source>Error loading {0} configuration</source>
        <translation>Virhe asetuksen {0} lataamisessa</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="386"/>
        <source>Exception saving config: {0}</source>
        <translation>Poikkeus asetusten tallentamisessa: {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="401"/>
        <source>DB type changed</source>
        <translation>Tietokantatyyppi muutettu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="410"/>
        <source>You must select a file for the database&lt;br&gt;or choose &quot;In memory&quot; type.</source>
        <translation>Sinun on valittava tiedosto tietokannalle&lt;br&gt;tai valittava tyypiksi &quot;Muistissa&quot;.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="433"/>
        <source>Language changed</source>
        <translation>Kieli muuutettu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="467"/>
        <source>UI theme changed</source>
        <translation>Käyttöliittymäteema muutettu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="467"/>
        <source>Restart the GUI in order to apply the new theme</source>
        <translation>Uudelleenkäynnistä käyttöliittymä, jotta uusi teema tulee voimaan</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="500"/>
        <source>Applying configuration on {0} ...</source>
        <translation>Toteutetaan asetuksia {0} ...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="508"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="520"/>
        <source>Exception saving node config {0}: {1}</source>
        <translation>Virhe solmun asetusten tallennuksessa {0}: {1}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="568"/>
        <source>Configuration applied.</source>
        <translation>Asetukset toteutettu.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="570"/>
        <source>Error applying configuration: {0}</source>
        <translation>Virhe asetusten toteuttamisessa: {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="607"/>
        <source>Hover the mouse over the texts to display the help&lt;br&gt;&lt;br&gt;Don&apos;t forget to visit the wiki: &lt;a href=&quot;{0}&quot;&gt;{0}&lt;/a&gt;</source>
        <translation>Vie hiiri tekstien päälle näyttääksesi ohjeen.&lt;br&gt;&lt;br&gt;Älä unohda käydä wikissä: &lt;a href=&quot;{0}&quot;&gt;{0}&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>proc_details</name>
    <message>
        <location filename="../../../opensnitch/dialogs/processdetails.py" line="100"/>
        <source>&lt;b&gt;Error loading process information:&lt;/b&gt; &lt;br&gt;&lt;br&gt;

</source>
        <translation>&lt;b&gt;Virhe prosessin tietojen lataamisessa:&lt;/b&gt; &lt;br&gt;&lt;br&gt;

</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/processdetails.py" line="119"/>
        <source>&lt;b&gt;Error stopping monitoring process:&lt;/b&gt;&lt;br&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;Virhe prosessin monitoroinnin pysäyttämisessä:&lt;/b&gt;&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/processdetails.py" line="159"/>
        <source>loading...</source>
        <translation>ladataan...</translation>
    </message>
</context>
<context>
    <name>rules</name>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="228"/>
        <source>There&apos;re no nodes connected.</source>
        <translation>Solmuja ei ole yhdistetty.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="245"/>
        <source>There&apos;s already a rule with this name.</source>
        <translation>Tällä nimellä on jo sääntö.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="271"/>
        <source>Rule applied.</source>
        <translation>Sovellettu sääntö.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="273"/>
        <source>Error applying rule: {0}</source>
        <translation>Virhe säännön soveltamisessa: {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="539"/>
        <source>&lt;b&gt;Error loading rule&lt;/b&gt;</source>
        <translation>&lt;b&gt;Virhe säännön lataamisessa&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="641"/>
        <source>protocol can not be empty, or uncheck it</source>
        <translation>protokolla ei voi olla tyhjä, tai poista valintaruutu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="655"/>
        <source>Protocol regexp error</source>
        <translation>Protokollan regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="659"/>
        <source>process path can not be empty</source>
        <translation>prosessipolku ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="673"/>
        <source>Process path regexp error</source>
        <translation>Prosessin polun regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="677"/>
        <source>command line can not be empty</source>
        <translation>komentorivi ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="691"/>
        <source>Command line regexp error</source>
        <translation>Komentorivin regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="695"/>
        <source>Network interface can not be empty</source>
        <translation>Verkkoliitäntä ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="709"/>
        <source>Network interface regexp error</source>
        <translation>Verkkoliitännän regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="713"/>
        <source>Source port can not be empty</source>
        <translation>Lähdeportti ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="727"/>
        <source>Source port regexp error</source>
        <translation>Lähdeportin regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="731"/>
        <source>Dest port can not be empty</source>
        <translation>Kohdeportti ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="745"/>
        <source>Dst port regexp error</source>
        <translation>Kohdeportin regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="749"/>
        <source>Dest host can not be empty</source>
        <translation>Kohdeisäntä ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="763"/>
        <source>Dst host regexp error</source>
        <translation>Kohdeisännän regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="767"/>
        <source>Source IP/Network can not be empty</source>
        <translation>Lähde-IP/-verkko ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="793"/>
        <source>Source IP regexp error</source>
        <translation>Lähde-IP:n regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="805"/>
        <source>Dest IP/Network can not be empty</source>
        <translation>Kohde-IP/-verkko ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="831"/>
        <source>Dst IP regexp error</source>
        <translation>Kohde-IP:n regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="843"/>
        <source>User ID can not be empty</source>
        <translation>Käyttäjä-ID ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="857"/>
        <source>User ID regexp error</source>
        <translation>Käyttäjä-ID:n regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="861"/>
        <source>PID field can not be empty</source>
        <translation>PID-kenttä ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="875"/>
        <source>PID field regexp error</source>
        <translation>PID-kentän regexp-virhe</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="931"/>
        <source>Lists field cannot be empty</source>
        <translation>Listat-kenttä ei voi olla tyhjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="933"/>
        <source>Lists field must be a directory</source>
        <translation>Listat-kentän on oltava hakemisto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="963"/>
        <source>Select at least one field.</source>
        <translation>Valitse vähintään yksi kenttä.</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="976"/>
        <source>&lt;b&gt;Rule not supported&lt;/b&gt;</source>
        <translation>&lt;b&gt;Sääntö ei tuettu&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>stats</name>
    <message>
        <location filename="../../../opensnitch/service.py" line="211"/>
        <source>WARNING</source>
        <translation>VAROITUS</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="776"/>
        <source>New node connected</source>
        <translation>Uusi solmu kytketty</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/customwidgets/addresstablemodel.py" line="17"/>
        <source>What</source>
        <translation>Mikä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/customwidgets/addresstablemodel.py" line="18"/>
        <source>Hits</source>
        <translation>Osumia</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/customwidgets/addresstablemodel.py" line="19"/>
        <source>Network name</source>
        <translation>Verkon nimi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="294"/>
        <source>Time</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Aika</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="298"/>
        <source>Node</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Solmu</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="295"/>
        <source>Action</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Toiminto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="305"/>
        <source>Destination</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Kohde</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="302"/>
        <source>Protocol</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Protokolla</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="303"/>
        <source>Process</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Prosessi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="309"/>
        <source>Rule</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Sääntö</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="287"/>
        <source>Name</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Nimi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="288"/>
        <source>Address</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Osoite</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="289"/>
        <source>Status</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Tila</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="290"/>
        <source>Hostname</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Isäntänimi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="291"/>
        <source>Uptime</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Käynnissäoloaika</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="423"/>
        <source>Version</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Versio</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="420"/>
        <source>Rules</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Säännöt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="296"/>
        <source>Duration</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Kesto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="297"/>
        <source>Description</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Kuvaus</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="299"/>
        <source>Enabled</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Käytössä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="300"/>
        <source>Precedence</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Ensisijaisuus</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="438"/>
        <source>Hits</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Osumia</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="304"/>
        <source>Cmdline</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Komentorivi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="306"/>
        <source>DstIP</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Kohde-IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="307"/>
        <source>DstHost</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Kohdeisäntä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="308"/>
        <source>DstPort</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Kohdeportti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="310"/>
        <source>UserID</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Käyttäjä-ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="311"/>
        <source>LastConnection</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Viimeinen yhteys</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="313"/>
        <source>Not running</source>
        <translation>Ei käynnissä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="314"/>
        <source>Disabled</source>
        <translation>Poissa käytöstä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="315"/>
        <source>Running</source>
        <translation>Käynnissä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="406"/>
        <source>Export rules</source>
        <translation>Vientisäännöt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="407"/>
        <source>Import rules</source>
        <translation>Tuontisäännöt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="408"/>
        <source>Export events to CSV</source>
        <translation>Vie tapahtumat CSV-tiedostoon</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="409"/>
        <source>Quit</source>
        <translation>Lopeta</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="421"/>
        <source>Connections</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Yhteydet</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="422"/>
        <source>Dropped</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Pudotetut</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="437"/>
        <source>What</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>Mikä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="636"/>
        <source>OpenSnitch Network Statistics {0}</source>
        <translation>OpenSnitch-verkkotilastot {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="638"/>
        <source>OpenSnitch Network Statistics for {0}</source>
        <translation>OpenSnitch-verkkotilastot {0}:lle</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="833"/>
        <source>Details</source>
        <translation>Yksityiskohdat</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="834"/>
        <source>Rules</source>
        <translation>Säännöt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="835"/>
        <source>New</source>
        <translation>Uusi</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="875"/>
        <source>Action</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="954"/>
        <source>Disable</source>
        <translation>Poista käytöstä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="956"/>
        <source>Enable</source>
        <translation>Ota käyttöön</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="961"/>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="960"/>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="931"/>
        <source>Apply to</source>
        <translation>Hae kohteeseen</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="932"/>
        <source>Export</source>
        <translation>Vie</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="940"/>
        <source>Allow</source>
        <translation>Salli</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="941"/>
        <source>Deny</source>
        <translation>Estä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="942"/>
        <source>Reject</source>
        <translation>Hylkää</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="945"/>
        <source>Always</source>
        <translation>Aina</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="946"/>
        <source>Until reboot</source>
        <translation>Uudelleenkäynnistykseen asti</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="959"/>
        <source>Duplicate</source>
        <translation>Kaksoiskappaleet</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="964"/>
        <source>To clipboard</source>
        <translation>Leikepöydälle</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="965"/>
        <source>To disk</source>
        <translation>Levylle</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1711"/>
        <source>    Are you sure?</source>
        <translation>    Oletko varma?</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2523"/>
        <source>Select a directory to export rules</source>
        <translation>Valitse hakemisto, johon säännöt viedään</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1189"/>
        <source>    Your are about to delete this rule.    </source>
        <translation>    Olet poistamassa tätä sääntöä.    </translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1191"/>
        <source>    Your are about to delete this entry.    </source>
        <translation>    Olet poistamassa tätä merkintää.    </translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1248"/>
        <source>Rule not found by that name and node</source>
        <translation>Sääntöä ei löydy kyseisellä nimellä ja solmulla</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1301"/>
        <source>&lt;b&gt;Error:&lt;/b&gt;&lt;br&gt;&lt;br&gt;</source>
        <comment>{0}</comment>
        <translation>&lt;b&gt;Virhe:&lt;/b&gt;&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1308"/>
        <source>Warning:</source>
        <translation>Varoitus:</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1678"/>
        <source>    You are about to delete this node.    </source>
        <translation>    Olet poistamassa tätä solmua.    </translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1687"/>
        <source>&lt;b&gt;Error deleting node&lt;/b&gt;&lt;br&gt;&lt;br&gt;</source>
        <comment>{0}</comment>
        <translation>&lt;b&gt;Virhe poistaessa solmua&lt;/b&gt;&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1711"/>
        <source>    You are about to delete this rule.    </source>
        <translation>    Olet poistamassa tätä sääntöä.    </translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2478"/>
        <source>Error exporting rules</source>
        <translation>Virhe vietäessä sääntöjä</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2552"/>
        <source>Select a directory with rules to import (JSON files)</source>
        <translation>Valitse hakemisto, jossa on tuotavia sääntöjä (JSON-tiedostot)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2566"/>
        <source>Rules imported fine</source>
        <translation>Säännöt tuotu hyvin</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2581"/>
        <source>Save as CSV</source>
        <translation>Tallenna CSV:nä</translation>
    </message>
</context>
</TS>
