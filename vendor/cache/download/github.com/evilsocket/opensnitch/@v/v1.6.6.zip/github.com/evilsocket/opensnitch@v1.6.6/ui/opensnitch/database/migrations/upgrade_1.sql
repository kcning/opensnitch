ALTER TABLE rules ADD COLUMN description;
