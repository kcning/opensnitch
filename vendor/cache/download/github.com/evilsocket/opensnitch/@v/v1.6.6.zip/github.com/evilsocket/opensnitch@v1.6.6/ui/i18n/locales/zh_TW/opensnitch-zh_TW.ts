<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="34"/>
        <source>opensnitch-qt</source>
        <translation>opensnitch-qt</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="300"/>
        <source>User ID</source>
        <translation>使用者 ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="334"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Executed from&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;執行來自&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="647"/>
        <source>TextLabel</source>
        <translation>文字標籤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="437"/>
        <source>Source IP</source>
        <translation>來源 IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="458"/>
        <source>Process ID</source>
        <translation>處理程序 ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="601"/>
        <source>Destination IP</source>
        <translation>目標 IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="622"/>
        <source>Dst Port</source>
        <translation>目標連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="702"/>
        <source>from this executable</source>
        <translation>來自此執行檔</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="707"/>
        <source>from this command line</source>
        <translation>來自此命令列</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="712"/>
        <source>this destination port</source>
        <translation>此目標連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="717"/>
        <source>this user</source>
        <translation>此使用者</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="722"/>
        <source>this destination ip</source>
        <translation>此目標 IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="727"/>
        <source>from this PID</source>
        <translation>來自此 PID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="751"/>
        <source>once</source>
        <translation>一次</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="756"/>
        <source>30s</source>
        <translation>30 秒</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="761"/>
        <source>5m</source>
        <translation>5 分鐘</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="766"/>
        <source>15m</source>
        <translation>15 分鐘</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="771"/>
        <source>30m</source>
        <translation>30 分鐘</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="776"/>
        <source>1h</source>
        <translation>1 小時</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="781"/>
        <source>until reboot</source>
        <translation>持續到重新啟動</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="786"/>
        <source>forever</source>
        <translation>永久</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="809"/>
        <source>action</source>
        <translation>動作</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="337"/>
        <source>Allow</source>
        <translation>允許</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/prompt.ui" line="865"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="14"/>
        <source>Firewall</source>
        <translation>防火牆</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Firewall&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;防火牆&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="275"/>
        <source>Profile</source>
        <translation>設定檔</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="346"/>
        <source>Deny</source>
        <translation>拒絕</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="313"/>
        <source>Outbound</source>
        <translation>對外</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="320"/>
        <source>Inbound</source>
        <translation>對內</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="375"/>
        <source>Allow inbound connections to a port</source>
        <translation>允許一個連接埠的對內連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="378"/>
        <source>Allow service (IN)</source>
        <translation>允許服務 (對內)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="398"/>
        <source>Exclude outbound connections to a port from being intercepted</source>
        <translation>排除被攔截到一個連接埠的對外連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="407"/>
        <source>Allow service (OUT)</source>
        <translation>允許服務 (對外)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall.ui" line="427"/>
        <source>New rule</source>
        <translation>新增規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="421"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="14"/>
        <source>Firewall rule</source>
        <translation>防火牆規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="26"/>
        <source>Node</source>
        <translation>節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="38"/>
        <source>Enable</source>
        <translation>啟用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="50"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="90"/>
        <source>Simple</source>
        <translation>簡易</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="154"/>
        <source>Add new condition</source>
        <translation>新增條件</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="177"/>
        <source>Remove selected condition</source>
        <translation>移除選定的條件</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="221"/>
        <source>Direction</source>
        <translation>方向</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="232"/>
        <source>IN</source>
        <translation>輸入</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="241"/>
        <source>OUT</source>
        <translation>輸出</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="250"/>
        <source>FORWARD</source>
        <translation>轉發</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="255"/>
        <source>PREROUTING</source>
        <translation>預路由</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="260"/>
        <source>POSTROUTING</source>
        <translation>後路由</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="268"/>
        <source>Action</source>
        <translation>動作</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="279"/>
        <source>ACCEPT</source>
        <translation>接受</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="288"/>
        <source>DROP</source>
        <translation>丟棄</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="297"/>
        <source>REJECT</source>
        <translation>拒絕</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="306"/>
        <source>RETURN</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="315"/>
        <source>QUEUE</source>
        <translation>佇列</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="323"/>
        <source>DNAT</source>
        <translation>DNAT</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="328"/>
        <source>SNAT</source>
        <translation>SNAT</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="333"/>
        <source>REDIRECT</source>
        <translation>重新導向</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="349"/>
        <source>depending on the Action (i.e.: target), the syntaxis of the parameters will vary.
Some examples:

QUEUE -&gt; num 0 (or 1, 2, ...)
REDIRECT, TPROXY, DNAT, SNAT, MASQUERADE:
 to :22
 to 192.168.1.254:8080
 to 192.168.1.254
 to 1024-2048 (masquerade)</source>
        <translation>依據動作（例如：目標），參數的語法將有所不同。
一些範例：

QUEUE -&gt; num 0（或 1、2、...）
REDIRECT、TPROXY、DNAT、SNAT、MASQUERADE：
 to :22
 to 192.168.1.254:8080
 to 192.168.1.254
 to 1024-2048（masquerade）</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="432"/>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="443"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="454"/>
        <source>Save</source>
        <translation>儲存</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/firewall_rule.ui" line="465"/>
        <source>Add</source>
        <translation>新增</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="14"/>
        <source>Preferences</source>
        <translation>偏好設定</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="39"/>
        <source>Pop-ups</source>
        <translation>彈出視窗</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="64"/>
        <source>Default options</source>
        <translation>預設選項</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="110"/>
        <source>If checked, this field will be selected when a pop-up is displayed</source>
        <translation>如果選取，則在顯示彈出視窗時將選擇此欄位</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="81"/>
        <source>User ID</source>
        <translation>使用者 ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="97"/>
        <source>Destination port</source>
        <translation>目標連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="113"/>
        <source>Destination IP</source>
        <translation>目標 IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1173"/>
        <source>deny</source>
        <translation>拒絕</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1182"/>
        <source>allow</source>
        <translation>允許</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="147"/>
        <source>reject</source>
        <translation>拒絕</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pop-up default action.&lt;/p&gt;&lt;p&gt;When a new outgoing connection is about to be established, this action will be selected by default, so if the timeout fires, this is the option that will be applied.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;While a pop-up is asking the user to allow or deny a connection:&lt;/p&gt;&lt;p&gt;1. new outgoing connections are denied.&lt;/p&gt;&lt;p&gt;2. known connections are allowed or denied based on the rules defined by the user.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;彈出視窗的預設動作。&lt;/p&gt;&lt;p&gt;當新的對外連線即將建立時，此動作將被預設選擇，所以如果逾時，這將是被套用的選項。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;當彈出視窗正在詢問使用者是否允許或拒絕連線時：&lt;/p&gt;&lt;p&gt;1. 新的對外連線被拒絕。&lt;/p&gt;&lt;p&gt;2. 已知的連線依據使用者定義的規則被允許或拒絕。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="872"/>
        <source>Action</source>
        <translation>動作</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="179"/>
        <source>center</source>
        <translation>中央</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="184"/>
        <source>top right</source>
        <translation>右上</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="189"/>
        <source>bottom right</source>
        <translation>右下</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="194"/>
        <source>top left</source>
        <translation>左上</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="199"/>
        <source>bottom left</source>
        <translation>左下</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1205"/>
        <source>once</source>
        <translation>一次</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="219"/>
        <source>30s</source>
        <translation>30 秒</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="224"/>
        <source>5m</source>
        <translation>5 分鐘</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="229"/>
        <source>15m</source>
        <translation>15 分鐘</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="234"/>
        <source>30m</source>
        <translation>30 分鐘</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="239"/>
        <source>1h</source>
        <translation>1 小時</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="244"/>
        <source>until reboot</source>
        <translation>持續到重新啟動</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="249"/>
        <source>forever</source>
        <translation>永久</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="263"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;By default when a new pop-up appears, in its simplest form, you&apos;ll be able to filter connections or applications by one property of the connection (executable, port, IP, etc).&lt;/p&gt;&lt;p&gt;With these options, you can choose multiple fields to filter connections for.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;預設情況下，當出現新的彈出視窗時，以其最簡單的形式，您將能夠按連線的一個屬性（執行檔、連接埠、IP 等）篩選連線或應用程式。&lt;/p&gt;&lt;p&gt;使用這些選項，您可以選擇多個欄位來篩選連線。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="266"/>
        <source>Filter connections also by:</source>
        <translation>也按以下方式篩選連線：</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="283"/>
        <source>by executable</source>
        <translation>依執行檔</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="288"/>
        <source>by command line</source>
        <translation>依命令列</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="293"/>
        <source>by destination port</source>
        <translation>依目標連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="298"/>
        <source>by destination ip</source>
        <translation>依目標 IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="303"/>
        <source>by user id</source>
        <translation>依使用者 ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="308"/>
        <source>by PID</source>
        <translation>依 PID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="323"/>
        <source>Default target</source>
        <translation>預設目標</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="330"/>
        <source>Default position on screen</source>
        <translation>在螢幕上的預設位置</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="340"/>
        <source>Pop-up default duration</source>
        <translation>彈出視窗的預設持續時間</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="343"/>
        <source>Duration</source>
        <translation>持續時間</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="356"/>
        <source>The advanced view allows you to easily select multiple fields to filter connections</source>
        <translation>進階檢視讓您可以輕鬆選擇多個欄位來篩選連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="359"/>
        <source>Show advanced view by default</source>
        <translation>預設顯示進階檢視</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="375"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the pop-ups will be displayed with the advanced view active.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;如果選取，彈出視窗將會以進階檢視顯示。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="466"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This timeout is the countdown you see when a pop-up dialog is shown.&lt;/p&gt;&lt;p&gt;If the pop-up is not answered, the default options will be applied.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;此逾時是顯示彈出對話框時看到的倒數計時。&lt;/p&gt;&lt;p&gt;如果未回答彈出視窗，將套用預設選項。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="469"/>
        <source>Default timeout</source>
        <translation>預設逾時</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="476"/>
        <source>Disable pop-ups, only display a notification</source>
        <translation>停用彈出視窗，只顯示通知</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="487"/>
        <source>UI</source>
        <translation>使用者介面</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1128"/>
        <source>General</source>
        <translation>一般</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="509"/>
        <source>Language</source>
        <translation>語言</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="533"/>
        <source>System</source>
        <translation>系統</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="547"/>
        <source>Theme</source>
        <translation>主題</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="554"/>
        <source>By default the GUI is started when login</source>
        <translation>預設登入時啟動圖形介面</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="557"/>
        <source>Autostart the GUI upon login</source>
        <translation>登入時自動啟動圖形介面</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="568"/>
        <source>Server</source>
        <translation>伺服器</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="581"/>
        <source>4MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="586"/>
        <source>8MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="591"/>
        <source>16MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="596"/>
        <source>32MiB</source>
        <translation>32 MiB</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="605"/>
        <source>Simple</source>
        <translation>簡易</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="610"/>
        <source>Simple TLS</source>
        <translation>簡易 TLS</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="615"/>
        <source>Mutual TLS</source>
        <translation>雙向 TLS</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="623"/>
        <source>Absolute path to the cert file</source>
        <translation>憑證檔案的絕對路徑</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="630"/>
        <source>Maximum size of each message from nodes. Default 4MB</source>
        <translation>來自節點的每個訊息的最大大小。預設 4MB</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="633"/>
        <source>Max gRPC channel size</source>
        <translation>gRPC 頻道的最大大小</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="640"/>
        <source>Absolute path to the cert key file</source>
        <translation>憑證金鑰檔案的絕對路徑</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="647"/>
        <source>&lt;p&gt;Simple: no authentication, TLS simple/mutual: use SSL certificates to authenticate nodes.&lt;/p&gt;&lt;p&gt;Visit the wiki for more information.&lt;/p&gt;</source>
        <translation>&lt;p&gt;簡易：無驗證，TLS 簡易/雙向：使用 SSL 憑證來驗證節點。&lt;/p&gt;&lt;p&gt;造訪 wiki 以取得更多資訊。&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="650"/>
        <source>Authentication type</source>
        <translation>驗證類型</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="657"/>
        <source>Absolute path to the CA cert file</source>
        <translation>CA 憑證檔案的絕對路徑</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="673"/>
        <source>Desktop notifications</source>
        <translation>桌面通知</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="685"/>
        <source>Enable</source>
        <translation>啟用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="703"/>
        <source>Use system notifications</source>
        <translation>使用系統通知</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="719"/>
        <source>Use Qt notifications</source>
        <translation>使用 Qt 通知</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="748"/>
        <source>Test</source>
        <translation>測試</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="769"/>
        <source>Events tab columns</source>
        <translation>事件標籤欄位</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="808"/>
        <source>Time</source>
        <translation>時間</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="824"/>
        <source>Rule</source>
        <translation>規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="840"/>
        <source>Node</source>
        <translation>節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="856"/>
        <source>Protocol</source>
        <translation>通訊協定</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="888"/>
        <source>Destination</source>
        <translation>目標</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="904"/>
        <source>Process</source>
        <translation>處理程序</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="914"/>
        <source>Command line</source>
        <translation>命令列</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="932"/>
        <source>Rules</source>
        <translation>規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="940"/>
        <source>When this option is selected, the rules of the selected duration won&apos;t be added to the list of temporary rules in the GUI.

Temporary rules will still be valid, and you can use them when prompted to allow/deny a new connection.</source>
        <translation>選擇此選項時，選定持續時間的規則將不會被新增到 GUI 的臨時規則列表中。

臨時規則仍然有效，並且您可以在提示允許/阻擋新連線時使用它們。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="945"/>
        <source>Don&apos;t save/Delete rules of duration</source>
        <translation>不儲存/刪除持續時間的規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="953"/>
        <source>any temporary rules</source>
        <translation>任何臨時規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="963"/>
        <source>30s or less</source>
        <translation>30 秒或更少</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="968"/>
        <source>5m or less</source>
        <translation>5 分鐘或更少</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="973"/>
        <source>15m or less</source>
        <translation>15 分鐘或更少</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="978"/>
        <source>30m or less</source>
        <translation>30 分鐘或更少</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="983"/>
        <source>1h or less</source>
        <translation>1 小時或更少</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1007"/>
        <source>Nodes</source>
        <translation>節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1019"/>
        <source>HostName</source>
        <translation>主機名稱</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1067"/>
        <source>Version</source>
        <translation>版本</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1109"/>
        <source>Apply configuration to all nodes</source>
        <translation>將設定套用到所有節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1134"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Address of the node.&lt;/p&gt;&lt;p&gt;Default: unix:///tmp/osui.sock (unix:// is mandatory if it&apos;s a Unix socket)&lt;/p&gt;&lt;p&gt;It can also be an IP address with the port: 127.0.0.1:50051&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;節點的位址。&lt;/p&gt;&lt;p&gt;預設：unix:///tmp/osui.sock（如果是 Unix socket，unix:// 是必須的）&lt;/p&gt;&lt;p&gt;也可以是帶有連接埠的 IP 位址：127.0.0.1:50051&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1137"/>
        <source>Address</source>
        <translation>位址</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1148"/>
        <source>unix:///tmp/osui.sock</source>
        <translation>unix:///tmp/osui.sock</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1156"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The default action will take place when there&apos;s no UI connected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;當沒有連接 UI 時，將進行預設動作。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1159"/>
        <source>Default action when the GUI is disconnected</source>
        <translation>GUI 斷開連接時的預設動作</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1194"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The default duration will take place when there&apos;s no UI connected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;當沒有連接 UI 時，將進行預設持續時間。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1197"/>
        <source>Default duration</source>
        <translation>預設的持續時間</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1210"/>
        <source>until restart</source>
        <translation>直到重新啟動</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1215"/>
        <source>always</source>
        <translation>永遠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1223"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, OpenSnitch will prompt you to allow or deny connections that don&apos;t have an associated PID, due to several reasons, mostly due to bad state connections.&lt;/p&gt;&lt;p&gt;The pop-up dialog will only contain information about the network connection.&lt;/p&gt;&lt;p&gt;There&apos;re some scenarios where these are valid connections though, like when establishing a VPN using WireGuard.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;如果選取，OpenSnitch 將提示您允許或拒絕沒有相關 PID 的連線，原因有很多，主要是因為連線狀態不佳。&lt;/p&gt;&lt;p&gt;彈出對話框只會包含有關網路連線的資訊。&lt;/p&gt;&lt;p&gt;儘管在某些情況下，這些是有效的連線，例如使用 WireGuard 建立 VPN。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1226"/>
        <source>Debug invalid connections</source>
        <translation>偵錯無效連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1240"/>
        <source>Process monitor method</source>
        <translation>處理程序監控方法</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1278"/>
        <source>Logging</source>
        <translation>記錄</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1291"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Log file to write logs.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;/dev/stdout will print logs to the standard output.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;寫入記錄的日誌檔案。&lt;br/&gt;&lt;/p&gt;&lt;p&gt;/dev/stdout 將會將記錄列印到標準輸出。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1294"/>
        <source>Log file</source>
        <translation>日誌檔案</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1301"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, OpenSnitch will log timestamp microseconds.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;如果選取，OpenSnitch 將記錄時間戳微秒。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1304"/>
        <source>Log timestamp microseconds</source>
        <translation>記錄時間戳微秒</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1348"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, OpenSnitch will use the UTC timezone for timestamps.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;如果選取，OpenSnitch 將使用 UTC 時區的時間戳。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1351"/>
        <source>Log UTC timestamps</source>
        <translation>記錄 UTC 時間戳</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1358"/>
        <source>Default log level</source>
        <translation>預設記錄等級</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1369"/>
        <source>/var/log/opensnitchd.log</source>
        <translation>/var/log/opensnitchd.log</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1374"/>
        <source>/dev/stdout</source>
        <translation>/dev/stdout</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1410"/>
        <source>Database</source>
        <translation>資料庫</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1445"/>
        <source>In memory</source>
        <translation>在記憶體中</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1450"/>
        <source>File</source>
        <translation>檔案</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1464"/>
        <source>Database type</source>
        <translation>資料庫類型</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1471"/>
        <source>Select</source>
        <translation>選擇</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1558"/>
        <source>minutes</source>
        <translation>分鐘</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1590"/>
        <source>Minutes between events purges</source>
        <translation>事件清除之間的分鐘數</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1616"/>
        <source>days</source>
        <translation>天</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1629"/>
        <source>Maximum days of events to keep</source>
        <translation>保留事件的最大天數</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1753"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1764"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/preferences.ui" line="1775"/>
        <source>Save</source>
        <translation>儲存</translation>
    </message>
</context>
<context>
    <name>ProcessDetailsDialog</name>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="14"/>
        <source>Process details</source>
        <translation>處理程序詳細資訊</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="61"/>
        <source>loading...</source>
        <translation>載入中...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="81"/>
        <source>CWD: loading...</source>
        <translation>CWD：載入中...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="93"/>
        <source>mem stats: loading...</source>
        <translation>記憶體狀態：載入中...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="121"/>
        <source>Status</source>
        <translation>狀態</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="135"/>
        <source>Open files</source>
        <translation>開啟檔案</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="149"/>
        <source>I/O Statistics</source>
        <translation>I/O 統計</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="163"/>
        <source>Memory mapped files</source>
        <translation>記憶體映射檔案</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="177"/>
        <source>Stack</source>
        <translation>堆疊</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="191"/>
        <source>Environment variables</source>
        <translation>環境變數</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="210"/>
        <source>Application pids</source>
        <translation>應用程式 PID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="240"/>
        <source>Start or stop monitoring this process</source>
        <translation>開始或停止監控此程序</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/process_details.ui" line="256"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
</context>
<context>
    <name>RulesDialog</name>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="20"/>
        <source>Rule</source>
        <translation>規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="56"/>
        <source>Action</source>
        <translation>動作</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="89"/>
        <source>Duration</source>
        <translation>持續時間</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="97"/>
        <source>once</source>
        <translation>一次</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="127"/>
        <source>until reboot</source>
        <translation>直到重新啟動</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="132"/>
        <source>always</source>
        <translation>永遠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="148"/>
        <source>Deny will just discard the connection</source>
        <translation>阻擋將僅丟棄連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="151"/>
        <source>Deny</source>
        <translation>阻擋</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="165"/>
        <source>Reject will drop the connection, and kill the socket that initiated it</source>
        <translation>拒絕將會丟棄連線，並終止啟動它的socket</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="168"/>
        <source>Reject</source>
        <translation>拒絕</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="185"/>
        <source>Allow will allow the connection</source>
        <translation>允許將允許連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="191"/>
        <source>Allow</source>
        <translation>允許</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="207"/>
        <source>Enable</source>
        <translation>啟用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="214"/>
        <source>If checked, this rule will take precedence over the rest of the rules. No others rules will be checked after this one.

You must name the rule in such manner that it&apos;ll be checked first, because they&apos;re checked in alphabetical order. For example:

[x] Priority - 000-priority-rule
[  ] Priority - 001-less-priority-rule</source>
        <translation>如果選取，此規則將優於其他規則。在此之後不會檢查其他規則。

您必須以這樣的方式命名規則，以便首先檢查它，因為它們按字母順序檢查。例如：

[x] 優先 - 000-priority-rule
[  ] 優先 - 001-less-priority-rule</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="222"/>
        <source>Priority rule</source>
        <translation>優先規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="238"/>
        <source>The rules are checked in alphabetical order, so you can name them accordingly to prioritize them.

000-allow-localhost
001-deny-broadcast
...</source>
        <translation>規則按字母順序檢查，因此您可以相應地命名它們以優先考慮它們。

000-allow-localhost
001-deny-broadcast
...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="245"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="300"/>
        <source>Node</source>
        <translation>節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="323"/>
        <source>Apply rule to all nodes</source>
        <translation>將規則套用到所有節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="346"/>
        <source>Applications</source>
        <translation>應用程式</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="355"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The value of this field is always the absolute path to the executable: /path/to/binary&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Examples:&lt;/p&gt;&lt;p&gt;- Simple: /path/to/binary&lt;/p&gt;&lt;p&gt;- Multiple paths: ^/usr/lib(64|)/firefox/firefox$&lt;/p&gt;&lt;p&gt;- Multiple binaries: ^(/usr/sbin/ntpd|/lib/systemd/systemd-timesyncd|/usr/bin/xbrlapi|/usr/bin/dirmngr)$ &lt;/p&gt;&lt;p&gt;- Deny/Allow executions from /tmp:&lt;/p&gt;&lt;p&gt;^/(var/|)tmp/.*$&lt;br/&gt;&lt;/p&gt;&lt;p&gt;For more examples visit the &lt;a href=&quot;https://github.com/evilsocket/opensnitch/wiki/Rules-examples&quot;&gt;wiki page&lt;/a&gt; or ask on the &lt;a href=&quot;https://github.com/evilsocket/opensnitch/discussions&quot;&gt;Discussion forums&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;此欄位的值始終是執行檔的絕對路徑：/path/to/binary&lt;br/&gt;&lt;/p&gt;&lt;p&gt;範例：&lt;/p&gt;&lt;p&gt;- 簡易：/path/to/binary&lt;/p&gt;&lt;p&gt;- 多路徑：^/usr/lib(64|)/firefox/firefox$&lt;/p&gt;&lt;p&gt;- 多個執行檔：^(/usr/sbin/ntpd|/lib/systemd/systemd-timesyncd|/usr/bin/xbrlapi|/usr/bin/dirmngr)$&lt;/p&gt;&lt;p&gt;- 拒絕/允許從 /tmp 執行：&lt;/p&gt;&lt;p&gt;^/(var/|)tmp/.*$&lt;br/&gt;&lt;/p&gt;&lt;p&gt;要取得更多範例，請造訪&lt;a href=&quot;https://github.com/evilsocket/opensnitch/wiki/Rules-examples&quot;&gt;wiki 頁面&lt;/a&gt;或在&lt;a href=&quot;https://github.com/evilsocket/opensnitch/discussions&quot;&gt;討論論壇&lt;/a&gt;提問。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="365"/>
        <source>Is regular expression</source>
        <translation>是正規表達式</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="372"/>
        <source>From this user ID</source>
        <translation>來自此使用者 ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="379"/>
        <source>From this command line</source>
        <translation>來自此命令列</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="389"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This field will contain and match the command line that was executed by the user.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;If the user typed the command, only the command will appear:&lt;/p&gt;&lt;p&gt;telnet 1.2.3.4&lt;br/&gt;&lt;/p&gt;&lt;p&gt;If the user typed the absolute or relative path to the command, that is what will appear:&lt;/p&gt;&lt;p&gt;/usr/bin/telnet 1.2.3.4&lt;/p&gt;&lt;p&gt;../../../usr/bin/telnet 1.2.3.4&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;此欄位將包含並符合使用者執行的命令列。&lt;br/&gt;&lt;/p&gt;&lt;p&gt;如果使用者輸入了命令，只會出現該命令：&lt;/p&gt;&lt;p&gt;telnet 1.2.3.4&lt;br/&gt;&lt;/p&gt;&lt;p&gt;如果使用者輸入了命令的絕對或相對路徑，那就會出現該內容：&lt;/p&gt;&lt;p&gt;/usr/bin/telnet 1.2.3.4&lt;/p&gt;&lt;p&gt;../../../usr/bin/telnet 1.2.3.4&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="399"/>
        <source>From this PID</source>
        <translation>來自此 PID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="466"/>
        <source>From this executable</source>
        <translation>來自此執行檔</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="473"/>
        <source>is regular expression</source>
        <translation>是正規表達式</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="485"/>
        <source>Network</source>
        <translation>網路</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="520"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Only TCP, UDP or UDPLITE are allowed&lt;/p&gt;&lt;p&gt;You can use regexp, i.e.: ^(TCP|UDP)$&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;僅允許 TCP、UDP 或 UDPLITE&lt;/p&gt;&lt;p&gt;您可以使用正規表達式，例如：^(TCP|UDP)$&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="526"/>
        <source>TCP</source>
        <translation>TCP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="560"/>
        <source>ICMP</source>
        <translation>ICMP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="565"/>
        <source>ICMP6</source>
        <translation>ICMP6</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="570"/>
        <source>SCTP</source>
        <translation>SCTP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="575"/>
        <source>SCTP6</source>
        <translation>SCTP6</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="586"/>
        <source>Commas or spaces are not allowed to specify multiple domains. 

Use regular expressions instead: 
.*(opensnitch|duckduckgo).com
.*\.google.com

or a single domain:
www.gnu.org - it&apos;ll only match www.gnu.org, nor ftp.gnu.org, nor www2.gnu.org, ...
gnu.org         - it&apos;ll only match gnu.org, nor www.gnu.org, nor ftp.gnu.org, ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="597"/>
        <source>www.domain.org, .*\.domain.org</source>
        <translation>www.domain.org, .*\.domain.org</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="604"/>
        <source>To this IP / Network</source>
        <translation>到此 IP / 網路</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="627"/>
        <source>Protocol</source>
        <translation>通訊協定</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="754"/>
        <source>You can specify a single IP:
- 192.168.1.1

or a regular expression:
- 192\.168\.1\.[0-9]+

multiple IPs:
- ^(192\.168\.1\.1|172\.16\.0\.1)$

You can also specify a subnet:
- 192.168.1.0/24

Note: Commas or spaces are not allowed to separate IPs or networks.</source>
        <translation>您可以指定單一 IP：
- 192.168.1.1

或是正規表達式：
- 192\.168\.1\.[0-9]+

多個 IP：
- ^(192\.168\.1\.1|172\.16\.0\.1)$

您也可以指定子網：
- 192.168.1.0/24

注意：不允許使用逗號或空格分隔 IP 或網路。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="659"/>
        <source>LAN</source>
        <translation>區域網路</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="664"/>
        <source>MULTICAST</source>
        <translation>多播</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="669"/>
        <source>127.0.0.0/8</source>
        <translation>127.0.0.0/8</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="674"/>
        <source>192.168.0.0/24</source>
        <translation>192.168.0.0/24</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="679"/>
        <source>192.168.1.0/24</source>
        <translation>92.168.1.0/24</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="684"/>
        <source>192.168.2.0/24</source>
        <translation>192.168.2.0/24</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="689"/>
        <source>192.168.0.0/16</source>
        <translation>192.168.0.0/16</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="694"/>
        <source>169.254.0.0/16</source>
        <translation>169.254.0.0/16</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="699"/>
        <source>172.16.0.0/12</source>
        <translation>172.16.0.0/12</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="704"/>
        <source>10.0.0.0/8</source>
        <translation>10.0.0.0/8</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="709"/>
        <source>::1/128</source>
        <translation>::1/128</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="714"/>
        <source>fc00::/7</source>
        <translation>fc00::/7</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="719"/>
        <source>ff00::/8</source>
        <translation>ff00::/8</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="724"/>
        <source>fe80::/10</source>
        <translation>fe80::/10</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="729"/>
        <source>fd00::/8</source>
        <translation>fd00::/8</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="737"/>
        <source>From this IP / Network</source>
        <translation>來自此 IP / 網路</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="744"/>
        <source>To this host</source>
        <translation>到此主機</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="857"/>
        <source>Network interface</source>
        <translation>網路介面</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="866"/>
        <source>From this port</source>
        <translation>來自此連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="912"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;You can specify multiple ports using regular expressions:&lt;/p&gt;&lt;p&gt;- 53, 80 or 443:&lt;/p&gt;&lt;p&gt;^(53|80|443)$&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;- 53, 443 or 5551, 5552, 5553, etc:&lt;/p&gt;&lt;p&gt;^(53|443|555[0-9])$&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;您可以使用正規表達式指定多個連接埠：&lt;/p&gt;&lt;p&gt;- 53、80 或 443：&lt;/p&gt;&lt;p&gt;^(53|80|443)$&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;- 53、443 或 5551、5552、5553 等：&lt;/p&gt;&lt;p&gt;^(53|443|555[0-9])$&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="896"/>
        <source>To this port</source>
        <translation>到此連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="926"/>
        <source>List of domains/IPs</source>
        <translation>網域/IP 清單</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="932"/>
        <source>To this list of network ranges</source>
        <translation>到此網路範圍清單</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="939"/>
        <source>To this list of IPs</source>
        <translation>到此 IP 清單</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="965"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory with files containing list of IPs to block or allow:&lt;/p&gt;&lt;p&gt;1.2.3.4.5&lt;/p&gt;&lt;p&gt;1.2.3.4.6&lt;/p&gt;&lt;p&gt;.&lt;/p&gt;&lt;p&gt;etc.&lt;/p&gt;&lt;p&gt;One IP per line. Empty lines or started with # are ignored.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;選擇一個含有要封鎖或允許的 IP 清單的檔案的目錄：&lt;/p&gt;&lt;p&gt;1.2.3.4.5&lt;/p&gt;&lt;p&gt;1.2.3.4.6&lt;/p&gt;&lt;p&gt;.&lt;/p&gt;&lt;p&gt;等等。&lt;/p&gt;&lt;p&gt;每行一個 IP。空行或以 # 開頭的行將被忽略。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="974"/>
        <source>To this list of domains</source>
        <translation>到此網域清單</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1000"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory with files containing list of network ranges to block or allow:&lt;/p&gt;&lt;p&gt;1.2.3.0/24&lt;/p&gt;&lt;p&gt;80.34.56.0/20&lt;/p&gt;&lt;p&gt;.&lt;/p&gt;&lt;p&gt;etc.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;One Network Range per line. Empty lines or started with # are ignored.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;選擇一個含有要封鎖或允許的網路範圍清單的檔案的目錄：&lt;/p&gt;&lt;p&gt;1.2.3.0/24&lt;/p&gt;&lt;p&gt;80.34.56.0/20&lt;/p&gt;&lt;p&gt;.&lt;/p&gt;&lt;p&gt;等等。&lt;br/&gt;&lt;/p&gt;&lt;p&gt;每行一個網路範圍。空行或以 # 開頭的行將被忽略。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1028"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory with lists of domains to block or allow.&lt;/p&gt;&lt;p&gt;Put inside that directory files with any extension containing lists of domains.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;The format of each entry of a list is as follow (hosts format):&lt;/p&gt;&lt;p&gt;127.0.0.1 www.domain.com&lt;/p&gt;&lt;p&gt;or &lt;/p&gt;&lt;p&gt;0.0.0.0 www.domain.com&lt;/p&gt;&lt;p&gt;Empty lines or started with # are ignored.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;選擇一個含有要封鎖或允許的網域清單的檔案的目錄。&lt;/p&gt;&lt;p&gt;在該目錄中放置含有網域清單的任何副檔名的檔案。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;每個清單條目的格式如下（hosts 格式）：&lt;/p&gt;&lt;p&gt;127.0.0.1 www.domain.com&lt;/p&gt;&lt;p&gt;或 &lt;/p&gt;&lt;p&gt;0.0.0.0 www.domain.com&lt;/p&gt;&lt;p&gt;空行或以 # 開頭的行將被忽略。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1043"/>
        <source>To this list of domains 
(regular expressions)</source>
        <translation>到此網域清單
(正規表達式)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1070"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory with files containing regular expressions of domains to block or allow:&lt;/p&gt;&lt;p&gt;.*\.example\.com&lt;/p&gt;&lt;p&gt;You can also use a domain as is: &amp;quot;example.com&amp;quot; , and it&apos;ll match whatever.example.com, whatever.example.com.localdomain, etc.&lt;/p&gt;&lt;p&gt;One domain per line. Empty lines or started with # are ignored.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;請在目錄中選擇一個含有要封鎖或允許的網域正規表達式的檔案：&lt;/p&gt;&lt;p&gt;.*\.example\.com&lt;/p&gt;&lt;p&gt;您也可以直接使用網域：&amp;quot;example.com&amp;quot;，它將符合 whatever.example.com、whatever.example.com.localdomain 等。&lt;/p&gt;&lt;p&gt;每行輸入一個網域。空行或以 # 開頭的行將被忽略。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1080"/>
        <source>More</source>
        <translation>更多</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1086"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;By default, the field of the rules are case-insensitive, i.e., if a process tries to access gOOgle.CoM and you have a rule to Deny .*google.com, the connection will be blocked.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;If you check this box, you have to specify the exact string (domain, executable, command line) that you want to filter.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;預設情況下，規則的欄位不區分大小寫，即，如果一個程序試圖存取 gOOgle.CoM，並且您有一個阻擋 .*google.com 的規則，則連線將被阻擋。&lt;br/&gt;&lt;/p&gt;&lt;p&gt;如果您選取此框，則必須指定您要篩選的確切字串（網域、執行檔、命令列）。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1089"/>
        <source>Case-sensitive</source>
        <translation>區分大小寫</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1096"/>
        <source>Don&apos;t log connections that match this rule</source>
        <translation>不記錄符合此規則的連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1099"/>
        <source>Don&apos;t log connections</source>
        <translation>不記錄連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/ruleseditor.ui" line="1145"/>
        <source>Description...</source>
        <translation>描述...</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="34"/>
        <source>OpenSnitch Network Statistics</source>
        <translation>OpenSnitch 網路統計</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="94"/>
        <source>Filter</source>
        <translation>篩選</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1814"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="107"/>
        <source>Allow</source>
        <translation>允許</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="116"/>
        <source>Deny</source>
        <translation>阻擋</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="125"/>
        <source>Reject</source>
        <translation>拒絕</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="143"/>
        <source>Ex.: firefox</source>
        <translation>例如：firefox</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="180"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="205"/>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="210"/>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="215"/>
        <source>200</source>
        <translation>200</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="220"/>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="233"/>
        <source>Delete all intercepted events</source>
        <translation>刪除所有被攔截的事件</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="333"/>
        <source>Create a new rule</source>
        <translation>建立新規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="376"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;hostname - 192.168.1.1&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;主機名稱 - 192.168.1.1&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="413"/>
        <source>Status</source>
        <translation>狀態</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="451"/>
        <source>Start or Stop interception</source>
        <translation>開始或停止攔截</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="496"/>
        <source>Events</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="829"/>
        <source>Nodes</source>
        <translation>節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="640"/>
        <source>Delete this node</source>
        <translation>刪除此節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="656"/>
        <source>Show the preferences of this node</source>
        <translation>顯示此節點的偏好設定</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="672"/>
        <source>Start or stop interception of this node</source>
        <translation>開始或停止攔截此節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1721"/>
        <source>Rules</source>
        <translation>規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="780"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="785"/>
        <source>Application rules</source>
        <translation>應用程式規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="939"/>
        <source>Permanent</source>
        <translation>永久</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="948"/>
        <source>Temporary</source>
        <translation>臨時</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="957"/>
        <source>System rules</source>
        <translation>系統規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="930"/>
        <source>All applications</source>
        <translation>所有應用程式</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="998"/>
        <source>enable</source>
        <translation>啟用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1028"/>
        <source>Edit rule</source>
        <translation>編輯規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1045"/>
        <source>Delete rule</source>
        <translation>刪除規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1069"/>
        <source>Hosts</source>
        <translation>主機</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1162"/>
        <source>Applications</source>
        <translation>應用程式</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1278"/>
        <source>Addresses</source>
        <translation>位址</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1371"/>
        <source>Ports</source>
        <translation>連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1458"/>
        <source>Users</source>
        <translation>使用者</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1565"/>
        <source>Connections</source>
        <translation>連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1617"/>
        <source>Dropped</source>
        <translation>已丟棄</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1669"/>
        <source>Uptime</source>
        <translation>運作時間</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/res/stats.ui" line="1788"/>
        <source>Version</source>
        <translation>版本</translation>
    </message>
</context>
<context>
    <name>contextual_menu</name>
    <message>
        <location filename="../../../opensnitch/service.py" line="48"/>
        <source>Statistics</source>
        <translation>統計</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="49"/>
        <source>Enable</source>
        <translation>啟用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="50"/>
        <source>Disable</source>
        <translation>停用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="51"/>
        <source>Help</source>
        <translation>幫助</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="52"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
</context>
<context>
    <name>firewall</name>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="96"/>
        <source>Configuration applied.</source>
        <translation>設定已套用。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="99"/>
        <source>Error: {0}</source>
        <translation>錯誤： {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="198"/>
        <source>Applying changes...</source>
        <translation>正在套用更改...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="235"/>
        <source>Error getting INPUT chain policy</source>
        <translation>取得 INPUT 鏈策略時出錯</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="242"/>
        <source>Error getting OUTPUT chain policy</source>
        <translation>取得 OUTPUT 鏈策略時出錯</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="295"/>
        <source>In order to configure firewall rules from the GUI, we need to use &apos;nftables&apos; instead of &apos;iptables&apos;</source>
        <translation>為了從 GUI 設定防火牆規則，我們需要使用 &apos;nftables&apos; 而不是 &apos;iptables&apos;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="309"/>
        <source>Enabling firewall...</source>
        <translation>正在啟用防火牆...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall.py" line="311"/>
        <source>Disabling firewall...</source>
        <translation>正在停用防火牆...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="71"/>
        <source>Dest Port</source>
        <translation>目標連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="72"/>
        <source>Source Port</source>
        <translation>來源連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="73"/>
        <source>Dest IP</source>
        <translation>目標 IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="74"/>
        <source>Source IP</source>
        <translation>來源 IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="75"/>
        <source>Input interface</source>
        <translation>輸入介面</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="76"/>
        <source>Output interface</source>
        <translation>輸出介面</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="77"/>
        <source>Set conntrack mark</source>
        <translation>設定 conntrack 標記</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="78"/>
        <source>Match conntrack mark</source>
        <translation>符合 conntrack 標記</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="79"/>
        <source>Match conntrack state(s)</source>
        <translation>符合 conntrack 狀態</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="80"/>
        <source>Set mark on packet</source>
        <translation>在封包上設定標記</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="81"/>
        <source>Match packet information</source>
        <translation>符合封包資訊</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="87"/>
        <source>Bandwidth quotas</source>
        <translation>頻寬配額</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="89"/>
        <source>Rate limit connections</source>
        <translation>限制連接速率</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="108"/>
        <source>
Supported formats:

 - Simple: 23
 - Ranges: 80-1024
 - Multiple ports: 80,443,8080
</source>
        <translation>
支援的格式：

 - 簡易：23
 - 範圍：80-1024
 - 多個連接埠：80,443,8080
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="134"/>
        <source>
Supported formats:

 - Simple: 1.2.3.4
 - IP ranges: 1.2.3.100-1.2.3.200
 - Network ranges: 1.2.3.4/24
</source>
        <translation>
支援的格式：

 - 簡易：1.2.3.4
 - IP 範圍：1.2.3.100-1.2.3.200
 - 網路範圍：1.2.3.4/24
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="147"/>
        <source>Match input interface. Regular expressions not allowed.
Use * to match multiple interfaces.</source>
        <translation>符合輸入介面。不允許使用正規表達式。
使用 * 符號符合多個介面。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="155"/>
        <source>Match output interface. Regular expressions not allowed.
Use * to match multiple interfaces.</source>
        <translation>符合輸出介面。不允許使用正規表達式。
使用 * 符號符合多個介面。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="163"/>
        <source>Set a conntrack mark on the connection, in decimal format.</source>
        <translation>在連線上設定 conntrack 標記，以十進位格式。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="173"/>
        <source>Match a conntrack mark of the connection, in decimal format.</source>
        <translation>符合連線的 conntrack 標記，以十進位格式。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="180"/>
        <source>Match conntrack states.

Supported formats:
 - Simple: new
 - Multiple states separated by commas: related,new
</source>
        <translation>符合 conntrack 狀態。

支援的格式：
 - 簡易：new
 - 逗號分隔狀態：related,new
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="195"/>
        <source>
Match packet&apos;s metainformation.

Value must be in decimal format, except for the &quot;l4proto&quot; option.
For l4proto it can be a lower case string, for example:
 tcp
 udp
 icmp,
 etc

If the value is decimal for protocol or lproto, it&apos;ll use it as the code of
that protocol.
</source>
        <translation>
符合封包的附加資訊。

值必須使用十進位格式，唯獨 &quot;l4proto&quot; 選項除外。
對於 l4proto，它可以是小寫字串，例如：
 tcp
 udp
 icmp
 等等

如果協議或 lproto 的值為十進位，它將用作該協議的代碼。
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="215"/>
        <source>Set a mark on the packet matching the specified conditions. The value is in decimal format.</source>
        <translation>在符合指定條件的封包上設定標記。值為十進位格式。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="223"/>
        <source>
Match ICMP codes.

Supported formats:
 - Simple: echo-request
 - Multiple separated by commas: echo-request,echo-reply
</source>
        <translation>
符合 ICMP 代碼。

支援的格式：
 - 簡易：echo-request
 - 逗號分隔：echo-request,echo-reply
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="236"/>
        <source>
Match ICMPv6 codes.

Supported formats:
 - Simple: echo-request
 - Multiple separated by commas: echo-request,echo-reply
</source>
        <translation>
符合 ICMPv6 代碼。

支援的格式：
 - 簡易：echo-request
 - 逗號分隔：echo-request,echo-reply
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="249"/>
        <source>Print a message when this rule matches a packet.</source>
        <translation>當此規則符合封包時，列印一條訊息。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="256"/>
        <source>
Apply quotas on connections.

For example when:
 - &quot;quota over 10/mbytes&quot; -&gt; apply the Action defined (DROP)
 - &quot;quota until 10/mbytes&quot; -&gt; apply the Action defined (ACCEPT)

The value must be in the format: VALUE/UNITS, for example:
 - 10mbytes, 1/gbytes, etc
</source>
        <translation>
對連線套用配額。

例如：
 - &quot;quota over 10/mbytes&quot; -&gt; 套用定義的動作 (DROP)
 - &quot;quota until 10/mbytes&quot; -&gt; 套用定義的動作 (ACCEPT)

值必須為 VALUE/UNITS 格式，例如：
 - 10mbytes, 1/gbytes, 等等
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="288"/>
        <source>
Apply limits on connections.

For example when:
 - &quot;limit over 10/mbytes/minute&quot; -&gt; apply the Action defined (DROP, ACCEPT, etc)
    (When there&apos;re more than 10MB per minute, apply an Action)

 - &quot;limit until 10/mbytes/hour&quot; -&gt; apply the Action defined (ACCEPT)

The value must be in the format: VALUE/UNITS/TIME, for example:
 - 10/mbytes/minute, 1/gbytes/hour, etc
</source>
        <translation>
對連線套用限制。

例如：
 - &quot;limit over 10/mbytes/minute&quot; -&gt; 套用定義的動作 (DROP, ACCEPT, 等等)
    (當每分鐘超過 10MB 時，套用一個動作)

 - &quot;limit until 10/mbytes/hour&quot; -&gt; 套用定義的動作 (ACCEPT)

值必須為 VALUE/UNITS/TIME 格式，例如：
 - 10/mbytes/minute, 1/gbytes/hour, 等等
</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="376"/>
        <source>Your protobuf version is incompatible, you need to install protobuf 3.8.0 or superior
(pip3 install --ignore-installed protobuf==3.8.0)</source>
        <translation>您的 protobuf 版本不相容，您需要安裝 protobuf 3.8.0 或更高版本
(pip3 install --ignore-installed protobuf==3.8.0)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="405"/>
        <source>Rule deleted</source>
        <translation>規則已刪除</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="411"/>
        <source>Rule saved</source>
        <translation>規則已儲存</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="413"/>
        <source>Rule added</source>
        <translation>規則已新增</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="423"/>
        <source>Error saving rule</source>
        <translation>儲存規則時出錯</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="450"/>
        <source>You can use &apos;,&apos; or &apos;-&apos; to specify multiple ports/IPs or ranges/values:&lt;br&gt;&lt;br&gt;ports: 22 or 22,443 or 50000-60000&lt;br&gt;IPs: 192.168.1.1 or 192.168.1.30-192.168.1.130&lt;br&gt;Values: echo-reply,echo-request&lt;br&gt;Values: new,established,related</source>
        <translation>您可以使用 &apos;,&apos; 或 &apos;-&apos; 來指定多個連接埠/IP 或範圍/值：&lt;br&gt;&lt;br&gt;連接埠：22 或 22,443 或 50000-60000&lt;br&gt;IP：192.168.1.1 或 192.168.1.30-192.168.1.130&lt;br&gt;值：echo-reply,echo-request&lt;br&gt;值：new,established,related</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="470"/>
        <source>Deleting rule, wait</source>
        <translation>正在刪除規則，請稍候</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="473"/>
        <source>Error updating rule</source>
        <translation>更新規則時出錯</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="508"/>
        <source>Add at least one statement.</source>
        <translation>至少新增一個語句。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="519"/>
        <source>Adding rule, wait</source>
        <translation>正在新增規則，請稍候</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="529"/>
        <source>&lt;select a statement&gt;</source>
        <translation>&lt;選擇一個語句&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="654"/>
        <source>num</source>
        <translation>數字</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="668"/>
        <source>to</source>
        <translation>到</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="834"/>
        <source>Equal</source>
        <translation>等於</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="835"/>
        <source>Not equal</source>
        <translation>不等於</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="836"/>
        <source>Greater or equal than</source>
        <translation>大於或等於</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="837"/>
        <source>Greater than</source>
        <translation>大於</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="838"/>
        <source>Less or equal than</source>
        <translation>小於或等於</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="839"/>
        <source>Less than</source>
        <translation>小於</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1007"/>
        <source>Warning: ct set mark value is empty, malformed rule?</source>
        <translation>警告：ct 設定標記值為空，規則格式錯誤？</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1523"/>
        <source>Firewall rule</source>
        <translation>防火牆規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1059"/>
        <source>Simple</source>
        <translation>簡易</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1064"/>
        <source>Advanced</source>
        <translation>進階</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1186"/>
        <source>This rule is not supported yet.</source>
        <translation>此規則目前尚未支援。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1251"/>
        <source>Exclude service</source>
        <translation>排除服務</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1263"/>
        <source>Allow inbound connections to the selected port.</source>
        <translation>允許到選定連接埠的對內連接。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1265"/>
        <source>Allow outbound connections to the selected port.</source>
        <translation>允許到選定連接埠的對外連接。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1341"/>
        <source>select a statement.</source>
        <translation>選擇一個語句。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1357"/>
        <source>value cannot be 0 or empty.</source>
        <translation>值不能為 0 或空。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1369"/>
        <source>the value format is 1024/kbytes (or bytes, mbytes, gbytes)</source>
        <translation>值的格式為 1024/kbytes (或 bytes, mbytes, gbytes)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1383"/>
        <source>the value format is 1024/kbytes/second (or bytes, mbytes, gbytes)</source>
        <translation>值的格式為 1024/kbytes/second (或 bytes, mbytes, gbytes)</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1386"/>
        <source>rate-limit not valid, use: bytes, kbytes, mbytes or gbytes.</source>
        <translation>速率限制無效，使用：bytes, kbytes, mbytes 或 gbytes。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1388"/>
        <source>time-limit not valid, use: second, minute, hour or day</source>
        <translation>時間限制無效，使用：second, minute, hour 或 day</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/firewall_rule.py" line="1455"/>
        <source>port not valid.</source>
        <translation>連接埠無效。</translation>
    </message>
</context>
<context>
    <name>messages</name>
    <message>
        <location filename="../../../opensnitch/service.py" line="301"/>
        <source>Info</source>
        <translation>資訊</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="305"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="309"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
</context>
<context>
    <name>notifications</name>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="767"/>
        <source>System notifications are not available, you need to install python3-notify2.</source>
        <translation>系統通知無法使用，您需要安裝 python3-notify2 套件。</translation>
    </message>
</context>
<context>
    <name>popups</name>
    <message>
        <location filename="../../../opensnitch/notifications.py" line="42"/>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="119"/>
        <source>Allow</source>
        <translation>允許</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="118"/>
        <source>Deny</source>
        <translation>拒絕</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/notifications.py" line="114"/>
        <source>New outgoing connection</source>
        <translation>新的對外連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="494"/>
        <source>is connecting to &lt;b&gt;%s&lt;/b&gt; on %s port %d</source>
        <translation>正在連線到 &lt;b&gt;%s&lt;/b&gt; 的 %s 連接埠 %d</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="52"/>
        <source>until reboot</source>
        <translation>直到重新啟動</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="54"/>
        <source>forever</source>
        <translation>永久</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="120"/>
        <source>Reject</source>
        <translation>拒絕</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="335"/>
        <source>Outgoing connection</source>
        <translation>對外連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="340"/>
        <source>Process launched from:</source>
        <translation>處理程序起始來源：</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="377"/>
        <source>from this executable</source>
        <translation>來自此執行檔</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="381"/>
        <source>from this command line</source>
        <translation>來自此命令列</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="383"/>
        <source>to port {0}</source>
        <translation>到埠號 {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="446"/>
        <source>to {0}</source>
        <translation>到 {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="386"/>
        <source>from user {0}</source>
        <translation>來自使用者 {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="390"/>
        <source>from this PID</source>
        <translation>來自此 PID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="403"/>
        <source>to {0}.*</source>
        <translation>到 {0}.*</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="456"/>
        <source>to *.{0}</source>
        <translation>到 *.{0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="490"/>
        <source>&lt;b&gt;Remote&lt;/b&gt; process %s running on &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;遠端&lt;/b&gt; 處理程序 %s 在 &lt;b&gt;%s&lt;/b&gt; 上執行</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="501"/>
        <source>is connecting to &lt;b&gt;%s&lt;/b&gt;, %s</source>
        <translation>正在連線到 &lt;b&gt;%s&lt;/b&gt;，%s</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/prompt.py" line="506"/>
        <source>is attempting to resolve &lt;b&gt;%s&lt;/b&gt; via %s, %s port %d</source>
        <translation>正試圖透過 %s，%s 連接埠 %d 解析 &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="458"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="44"/>
        <source>Restart the GUI in order changes to take effect</source>
        <translation>重新啟動 GUI 以使變更生效</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="438"/>
        <source>There&apos;re no nodes connected</source>
        <translation>沒有任何節點已連線。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="183"/>
        <source>System default</source>
        <translation>系統預設</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="534"/>
        <source>System</source>
        <translation>系統</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="206"/>
        <source>Themes not available. Install qt-material: pip3 install qt-material</source>
        <translation>主題不可用。安裝 qt-material：pip3 install qt-material</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="337"/>
        <source>Server address can not be empty</source>
        <translation>伺服器位址不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="368"/>
        <source>Error loading {0} configuration</source>
        <translation>載入 {0} 設定時出錯</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="436"/>
        <source>Exception saving config: {0}</source>
        <translation>儲存設定時發生例外：{0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="452"/>
        <source>DB type changed</source>
        <translation>DB 類型已變更</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="458"/>
        <source>You must select a file for the database&lt;br&gt;or choose &quot;In memory&quot; type.</source>
        <translation>您必須為資料庫選擇一個檔案&lt;br&gt;或是選擇「記憶體中」的類型。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="490"/>
        <source>Certificates changed</source>
        <translation>憑證已變更</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="504"/>
        <source>Language changed</source>
        <translation>語言已變更</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="535"/>
        <source>UI theme changed</source>
        <translation>UI 主題已變更</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="565"/>
        <source>Applying configuration on {0} ...</source>
        <translation>正在對 {0} 套用設定 ...</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="573"/>
        <source>Ok</source>
        <translation>確定</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="583"/>
        <source>Exception saving node config {0}: {1}</source>
        <translation>儲存節點設定 {0} 時發生例外：{1}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="594"/>
        <source>Certs fields cannot be empty.</source>
        <translation>憑證欄位不能為空。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="597"/>
        <source>cert file has excessive permissions, it should have 0600</source>
        <translation>憑證檔案權限過大，應設為 0600</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="601"/>
        <source>cert key file has excessive permissions, it should have 0600</source>
        <translation>憑證金鑰檔案權限過大，應設為 0600</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="607"/>
        <source>CA cert file has excessive permissions, it should have 0600</source>
        <translation>CA 憑證檔案權限過大，應設為 0600</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="667"/>
        <source>Configuration applied.</source>
        <translation>設定已套用。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="669"/>
        <source>Error applying configuration: {0}</source>
        <translation>套用設定時出錯：{0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="674"/>
        <source>Certs changed</source>
        <translation>憑證已變更</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="710"/>
        <source>Hover the mouse over the texts to display the help&lt;br&gt;&lt;br&gt;Don&apos;t forget to visit the wiki: &lt;a href=&quot;{0}&quot;&gt;{0}&lt;/a&gt;</source>
        <translation>將滑鼠停在文字上以顯示幫助&lt;br&gt;&lt;br&gt;別忘了造訪 wiki：&lt;a href=&quot;{0}&quot;&gt;{0}&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/preferences.py" line="737"/>
        <source>Auth type changed</source>
        <translation>認證類型已變更</translation>
    </message>
</context>
<context>
    <name>proc_details</name>
    <message>
        <location filename="../../../opensnitch/dialogs/processdetails.py" line="100"/>
        <source>&lt;b&gt;Error loading process information:&lt;/b&gt; &lt;br&gt;&lt;br&gt;

</source>
        <translation>&lt;b&gt;載入處理程序資訊時出錯：&lt;/b&gt; &lt;br&gt;&lt;br&gt;

</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/processdetails.py" line="119"/>
        <source>&lt;b&gt;Error stopping monitoring process:&lt;/b&gt;&lt;br&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;停止監控處理程序時出錯：&lt;/b&gt;&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/processdetails.py" line="159"/>
        <source>loading...</source>
        <translation>載入中...</translation>
    </message>
</context>
<context>
    <name>rules</name>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="238"/>
        <source>There&apos;re no nodes connected.</source>
        <translation>沒有已連線的節點。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="255"/>
        <source>There&apos;s already a rule with this name.</source>
        <translation>已經有一條相同名稱的規則。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="281"/>
        <source>Rule applied.</source>
        <translation>規則已套用。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="283"/>
        <source>Error applying rule: {0}</source>
        <translation>套用規則出錯：{0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="549"/>
        <source>&lt;b&gt;Error loading rule&lt;/b&gt;</source>
        <translation>&lt;b&gt;載入規則出錯&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="651"/>
        <source>protocol can not be empty, or uncheck it</source>
        <translation>通訊協定不能為空或取消勾選</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="665"/>
        <source>Protocol regexp error</source>
        <translation>通訊協定正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="669"/>
        <source>process path can not be empty</source>
        <translation>處理程序路徑不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="683"/>
        <source>Process path regexp error</source>
        <translation>處理程序路徑正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="687"/>
        <source>command line can not be empty</source>
        <translation>命令列不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="701"/>
        <source>Command line regexp error</source>
        <translation>命令列正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="705"/>
        <source>Network interface can not be empty</source>
        <translation>網路介面不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="719"/>
        <source>Network interface regexp error</source>
        <translation>網路介面正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="723"/>
        <source>Source port can not be empty</source>
        <translation>來源連接埠不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="737"/>
        <source>Source port regexp error</source>
        <translation>來源連接埠正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="741"/>
        <source>Dest port can not be empty</source>
        <translation>目標連接埠不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="755"/>
        <source>Dst port regexp error</source>
        <translation>目標連接埠正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="759"/>
        <source>Dest host can not be empty</source>
        <translation>目標主機不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="773"/>
        <source>Dst host regexp error</source>
        <translation>目標主機正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="777"/>
        <source>Source IP/Network can not be empty</source>
        <translation>來源 IP/網路不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="803"/>
        <source>Source IP regexp error</source>
        <translation>來源 IP 正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="815"/>
        <source>Dest IP/Network can not be empty</source>
        <translation>目標 IP/網路不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="841"/>
        <source>Dst IP regexp error</source>
        <translation>目標 IP 正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="856"/>
        <source>User ID can not be empty</source>
        <translation>使用者 ID 不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="873"/>
        <source>User ID regexp error</source>
        <translation>使用者 ID 正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="876"/>
        <source>Invalid UID, it must be a digit.</source>
        <translation>無效的 UID，必須是數字。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="890"/>
        <source>PID field can not be empty</source>
        <translation>PID 欄位不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="904"/>
        <source>PID field regexp error</source>
        <translation>PID 欄位正規表達式錯誤</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="960"/>
        <source>Lists field cannot be empty</source>
        <translation>列表欄位不能為空</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="962"/>
        <source>Lists field must be a directory</source>
        <translation>列表欄位必須是目錄</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="992"/>
        <source>Select at least one field.</source>
        <translation>至少選擇一個欄位。</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/ruleseditor.py" line="1005"/>
        <source>&lt;b&gt;Rule not supported&lt;/b&gt;</source>
        <translation>&lt;b&gt;不支援的規則&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>stats</name>
    <message>
        <location filename="../../../opensnitch/service.py" line="231"/>
        <source>WARNING</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/service.py" line="796"/>
        <source>New node connected</source>
        <translation>新節點已連接</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/customwidgets/addresstablemodel.py" line="17"/>
        <source>What</source>
        <translation>什麼</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/customwidgets/addresstablemodel.py" line="18"/>
        <source>Hits</source>
        <translation>命中次數</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/customwidgets/addresstablemodel.py" line="19"/>
        <source>Network name</source>
        <translation>網路名稱</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="293"/>
        <source>Time</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>時間</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="297"/>
        <source>Node</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>節點</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="294"/>
        <source>Action</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>動作</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="304"/>
        <source>Destination</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>目的地</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="301"/>
        <source>Protocol</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>協議</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="302"/>
        <source>Process</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>處理程序</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="308"/>
        <source>Rule</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="286"/>
        <source>Name</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="287"/>
        <source>Address</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>位址</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="288"/>
        <source>Status</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>狀態</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="289"/>
        <source>Hostname</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>主機名稱</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="290"/>
        <source>Uptime</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>運作時間</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="422"/>
        <source>Version</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>版本</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="419"/>
        <source>Rules</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="295"/>
        <source>Duration</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>持續時間</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="296"/>
        <source>Description</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="298"/>
        <source>Enabled</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>已啟用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="299"/>
        <source>Precedence</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>優先順序</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="437"/>
        <source>Hits</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>命中次數</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="303"/>
        <source>Cmdline</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>命令列</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="305"/>
        <source>DstIP</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>目標 IP</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="306"/>
        <source>DstHost</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>目標主機</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="307"/>
        <source>DstPort</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>目標連接埠</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="309"/>
        <source>UserID</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>使用者 ID</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="310"/>
        <source>LastConnection</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>最後連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="312"/>
        <source>Not running</source>
        <translation>未運作</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="313"/>
        <source>Disabled</source>
        <translation>已停用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="314"/>
        <source>Running</source>
        <translation>運作中</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="405"/>
        <source>Export rules</source>
        <translation>匯出規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="406"/>
        <source>Import rules</source>
        <translation>匯入規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="407"/>
        <source>Export events to CSV</source>
        <translation>將事件匯出至 CSV</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="408"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="420"/>
        <source>Connections</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>連線</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="421"/>
        <source>Dropped</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>已丟棄</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="436"/>
        <source>What</source>
        <comment>This is a word, without spaces and symbols.</comment>
        <translation>內容</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="635"/>
        <source>OpenSnitch Network Statistics {0}</source>
        <translation>OpenSnitch 網路統計 {0}</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="637"/>
        <source>OpenSnitch Network Statistics for {0}</source>
        <translation>OpenSnitch 為 {0} 的網路統計</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="832"/>
        <source>Details</source>
        <translation>詳細資訊</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="833"/>
        <source>Rules</source>
        <translation>規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="834"/>
        <source>New</source>
        <translation>新增</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="942"/>
        <source>Export</source>
        <translation>匯出</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="875"/>
        <source>Action</source>
        <translation>動作</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="964"/>
        <source>Disable</source>
        <translation>停用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="966"/>
        <source>Enable</source>
        <translation>啟用</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="971"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="970"/>
        <source>Edit</source>
        <translation>編輯</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="974"/>
        <source>To clipboard</source>
        <translation>複製到剪貼簿</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="941"/>
        <source>Apply to</source>
        <translation>套用於</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="950"/>
        <source>Allow</source>
        <translation>允許</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="951"/>
        <source>Deny</source>
        <translation>阻擋</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="952"/>
        <source>Reject</source>
        <translation>拒絕</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="955"/>
        <source>Always</source>
        <translation>總是</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="956"/>
        <source>Until reboot</source>
        <translation>持續到重新啟動</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="969"/>
        <source>Duplicate</source>
        <translation>複製</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="975"/>
        <source>To disk</source>
        <translation>儲存到磁碟</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1730"/>
        <source>    Are you sure?</source>
        <translation>    您確定嗎？</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2559"/>
        <source>Select a directory to export rules</source>
        <translation>選擇一個目錄以匯出規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1207"/>
        <source>    Your are about to delete this rule.    </source>
        <translation>    您即將刪除此規則。    </translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1209"/>
        <source>    Your are about to delete this entry.    </source>
        <translation>    您即將刪除此條目。    </translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1266"/>
        <source>Rule not found by that name and node</source>
        <translation>未找到該名稱和節點的規則</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1319"/>
        <source>Error:</source>
        <translation>錯誤：</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1327"/>
        <source>Warning:</source>
        <translation>警告：</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1697"/>
        <source>    You are about to delete this node.    </source>
        <translation>    您即將刪除此節點。    </translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1706"/>
        <source>&lt;b&gt;Error deleting node&lt;/b&gt;&lt;br&gt;&lt;br&gt;</source>
        <comment>{0}</comment>
        <translation>&lt;b&gt;刪除節點時出錯&lt;/b&gt;&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="1730"/>
        <source>    You are about to delete this rule.    </source>
        <translation>    您即將刪除此規則。    </translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2514"/>
        <source>Error exporting rules</source>
        <translation>匯出規則時出錯</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2588"/>
        <source>Select a directory with rules to import (JSON files)</source>
        <translation>選擇一個含有要匯入的規則的目錄（JSON 檔案）</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2602"/>
        <source>Rules imported fine</source>
        <translation>規則匯入成功</translation>
    </message>
    <message>
        <location filename="../../../opensnitch/dialogs/stats.py" line="2617"/>
        <source>Save as CSV</source>
        <translation>另存為 CSV</translation>
    </message>
</context>
</TS>
