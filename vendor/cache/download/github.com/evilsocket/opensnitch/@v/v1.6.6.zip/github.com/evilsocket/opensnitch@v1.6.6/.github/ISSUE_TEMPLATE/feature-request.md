---
name: 💡 Feature request
about: Suggest an idea 
title: '[Feature Request] <title>'
labels: feature
assignees: ''

---

<!--
Note: Please, use the search box to see if this feature has already been requested.
-->

### Summary:
<!-- A concise description of the new feature. -->
